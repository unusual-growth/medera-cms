<?php
$needSizer = $needSizer ?? false;
$needPlaceholder = $needPlaceholder ?? false;
?>

<?php if($needSizer || $needPlaceholder): ?>
<div
    class="<?php echo e($wrapperClasses); ?>"
    style="<?php echo e($wrapperStyles); ?>"
    data-twill-image-wrapper
>
<?php endif; ?>
    <?php if($needPlaceholder): ?>
        <?php echo $__env->make('twill-image::placeholder', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <?php echo $__env->make('twill-image::main-image', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php if($needSizer || $needPlaceholder): ?>
</div>
<?php endif; ?>
<?php /**PATH /var/www/medera-cms/vendor/area17/twill-image/src/../resources/views/wrapper.blade.php ENDPATH**/ ?>