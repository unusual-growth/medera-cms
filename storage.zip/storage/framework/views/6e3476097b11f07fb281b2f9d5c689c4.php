
<head>
    
    
    <!-- End Google Tag Manager -->
    
    <link rel="icon" type="image/x-icon" href="/assets/favicon.ico">

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta http-equiv="ScreenOrientation" content="autoRotate:disabled">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />


    <?php if(isset($item)): ?>
    <?php echo SEOMeta::generate(); ?>

    <?php echo OpenGraph::generate(); ?>

    <?php echo Twitter::generate(); ?>

    <?php endif; ?>

    <?php if(isset($meta)): ?>
        <title><?php echo e($meta->title); ?></title>
        <meta name="description" content="<?php echo e($meta->description); ?>">
        <?php if(isset($meta->index)): ?>
            <meta name="robots" content="<?php echo e($meta->index); ?>">
        <?php endif; ?>
        <?php if(isset($canonical)): ?>
            <link rel="canonical" href="<?php echo e($canonical); ?>" />
        <?php elseif(isset($localCanonical)): ?>
            
            <link rel="canonical" href="<?php echo e($canonicalUrl); ?>" />
        <?php endif; ?>
    <?php endif; ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css">
<script src="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js"></script>


    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Maven+Pro:wght@400..900&family=Open+Sans:ital,wght@0,300..800;1,300..800&family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">

    
    <script
        src="https://code.jquery.com/jquery-3.7.1.min.js"
        integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo="
        crossorigin="anonymous"></script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
    <?php if(isset($item->schema)): ?>
        <script type="application/ld+json">
            <?php echo $item->schema; ?>

        </script>
    <?php endif; ?>
    <?php if(isset($jsonLd)): ?>
        <?php echo $jsonLd; ?>

    <?php endif; ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/intl-tel-input@18.2.1/build/css/intlTelInput.css">
    <script src="https://cdn.jsdelivr.net/npm/intl-tel-input@18.2.1/build/js/intlTelInput.min.js"></script>
    <script src="/vendor/unusual_form/js/step-form.js"></script>
    <script src="/vendor/unusual_form/js/form-validation.js"></script>
    <?php echo app('Illuminate\Foundation\Vite')([
        "resources/js/app.js",
        "resources/scss/style.scss"
    ]); ?>
    <?php echo $__env->yieldPushContent('preload'); ?>
    
    <?php echo $__env->yieldPushContent('custom-css'); ?>
    
</head>
<?php /**PATH /var/www/medera-cms/resources/views/site/meta/head.blade.php ENDPATH**/ ?>