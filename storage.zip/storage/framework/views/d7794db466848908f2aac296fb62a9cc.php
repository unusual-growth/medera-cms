<input type="hidden"
    name="<?php echo e($input_name); ?>"
    value="<?php echo e($value); ?>"
    id="<?php echo e($input_id); ?>"
/>
<?php /**PATH /var/www/medera-cms/resources/views/vendor/unusual_form/inputs/_hidden.blade.php ENDPATH**/ ?>