<div class="library-card ">
    <?php
        $has_image = $article->hasImage('library-image');
        if ($has_image) {
            $image = TwillImage::make($article, 'library-image')->crop('thumbnail')->width(421)->height(252)->toArray();
        }
    ?>
    <?php if($has_image): ?>
        <?php echo TwillImage::render($image); ?>

    <?php else: ?>
        <div style="width: 100%; height: 320px; color: white; display: flex; justify-content: center; align-items: center;">
            Please add an image.
        </div>
    <?php endif; ?>
    <div>
        <h2 class="heading">
            <?php echo e($article->title); ?>

        </h2>
        <div class="desc">
            <p>
                <?php echo e($article->description); ?>

            </p>
        </div>
        <div class="bottom-line">
            <p class="date">         <?php echo e(\Carbon\Carbon::parse($article->publish_start_date)->translatedFormat('d M Y')); ?>

            </p>
            <a class="library-cta" href="<?php echo e(route('article', $article->slug)); ?>">
                <?php echo e(__('frontend.Read More')); ?>

            </a>
        </div>
    </div>
</div>
<?php /**PATH /var/www/medera-cms/resources/views/components/article-card.blade.php ENDPATH**/ ?>