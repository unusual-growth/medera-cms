<?php if($unpack): ?>
    <a17-multiselect
        label="<?php echo e($label); ?>"
        <?php echo $formFieldName(); ?>

        :options="<?php echo e(json_encode($options)); ?>"
        :grid="true"
        :columns="<?php echo e($columns); ?>"
        :inline="false"
        <?php if($min ?? false): ?> :min="<?php echo e($min); ?>" <?php endif; ?>
        <?php if($max ?? false): ?> :max="<?php echo e($max); ?>" <?php endif; ?>
        <?php if($inModal): ?> :in-modal="true" <?php endif; ?>
        <?php if($addNew): ?> add-new='<?php echo e($storeUrl); ?>' <?php elseif($note): ?> note='<?php echo e($note); ?>' <?php endif; ?>
        <?php if($disabled ?? false): ?> :disabled="true" <?php endif; ?>
        in-store="currentValue"
    >
        <?php if($addNew): ?>
            <div slot="addModal">
                <?php
            if( view()->exists(twillViewName(($formModuleName ?? null), 'create'))) {
                echo $__env->make(twillViewName(($formModuleName ?? null), 'create'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->with( ['renderForModal' => true, 'fieldsInModal' => true])->render();
            } elseif( view()->exists('twill.partials.create')) {
                echo $__env->make('twill.partials.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->with( ['renderForModal' => true, 'fieldsInModal' => true])->render();
            } elseif( view()->exists('twill::'.($formModuleName ?? null).'.create')) {
                echo $__env->make('twill::'.($formModuleName ?? null).'.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->with( ['renderForModal' => true, 'fieldsInModal' => true])->render();
            } elseif( view()->exists('twill::partials.create')) {
                echo $__env->make('twill::partials.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->with( ['renderForModal' => true, 'fieldsInModal' => true])->render();
            }
            ?>
            </div>
        <?php endif; ?>
    </a17-multiselect>
<?php else: ?>
    <a17-vselect
        label="<?php echo e($label); ?>"
        <?php echo $formFieldName(); ?>

        :options="<?php echo e(json_encode($options)); ?>"
        <?php if($emptyText ?? false): ?> empty-text="<?php echo e($emptyText); ?>" <?php endif; ?>
        <?php if($placeholder ?? false): ?> placeholder="<?php echo e($placeholder); ?>" <?php endif; ?>
        <?php if($inModal): ?> :in-modal="true" <?php endif; ?>
        <?php if($addNew): ?> add-new='<?php echo e($storeUrl); ?>' <?php elseif($note): ?> note='<?php echo e($note); ?>' <?php endif; ?>
        <?php if($searchable ?? $endpoint ?? false): ?> :searchable="true" <?php endif; ?>
        <?php if($endpoint ?? false): ?> endpoint="<?php echo e($endpoint); ?>" <?php endif; ?>
        <?php if($disabled ?? false): ?> :disabled="true" <?php endif; ?>
        :multiple="true"
        in-store="inputValue"
        <?php if($taggable ?? false): ?> taggable="<?php echo e($taggable); ?>" <?php endif; ?>
        <?php if($searchable ?? false): ?> searchable="<?php echo e($searchable); ?>" <?php endif; ?>
        <?php if($pushTags ?? false): ?> pushTags="<?php echo e($pushTags); ?>" <?php endif; ?>
    >
        <?php if($addNew): ?>
            <div slot="addModal">
                <?php
            if( view()->exists(twillViewName(($formModuleName ?? null), 'create'))) {
                echo $__env->make(twillViewName(($formModuleName ?? null), 'create'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->with( ['renderForModal' => true, 'fieldsInModal' => true])->render();
            } elseif( view()->exists('twill.partials.create')) {
                echo $__env->make('twill.partials.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->with( ['renderForModal' => true, 'fieldsInModal' => true])->render();
            } elseif( view()->exists('twill::'.($formModuleName ?? null).'.create')) {
                echo $__env->make('twill::'.($formModuleName ?? null).'.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->with( ['renderForModal' => true, 'fieldsInModal' => true])->render();
            } elseif( view()->exists('twill::partials.create')) {
                echo $__env->make('twill::partials.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->with( ['renderForModal' => true, 'fieldsInModal' => true])->render();
            }
            ?>
            </div>
        <?php endif; ?>
    </a17-vselect>
<?php endif; ?>

<?php if (! ($renderForBlocks || $renderForModal || (!isset($item->$name) && is_null($formFieldsValue = getFormFieldsValue($form_fields, $name))))): ?>
<?php $__env->startPush('vuexStore'); ?>
    window['<?php echo e(config('twill.js_namespace')); ?>'].STORE.form.fields.push({
        name: '<?php echo e($name); ?>',
        value: <?php echo json_encode(isset($item) && isset($item->$name) ? Arr::pluck($item->$name, 'id') : $formFieldsValue); ?>

    })
<?php $__env->stopPush(); ?>
<?php endif; ?>
<?php /**PATH /var/www/medera-cms/resources/views/vendor/twill/partials/form/_multi_select.blade.php ENDPATH**/ ?>