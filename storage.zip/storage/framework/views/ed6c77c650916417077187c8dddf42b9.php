<?php $__env->startSection('appTypeClass', 'body--form'); ?>

<?php $__env->startPush('extra_css'); ?>
    <?php if(app()->isProduction()): ?>
        <link href="<?php echo e(twillAsset('main-form.css')); ?>" rel="preload" as="style" crossorigin />
    <?php endif; ?>

    <?php if (! (config('twill.dev_mode', false))): ?>
        <link href="<?php echo e(twillAsset('main-form.css')); ?>" rel="stylesheet" crossorigin />
    <?php endif; ?>

    <style>
        .button--back {
            display: inline-flex;
            align-items: center;
            padding: 8px 16px;
            background-color: #1d9f3c;
            border: 1px solid #fff;
            color: #fff;
            border-radius: 4px;
            transition: all 0.2s ease;
            text-decoration: none;
            position: absolute;
            left: 50px;
            top: 27px;
            z-index: 100;
            margin: 0;
        }
   

        .button--back:hover {
            background-color: #e0e0e0;
            text-decoration: none;
        }

        .button--back .icon {
            margin-right: 8px;
            width: 16px;
            height: 16px;
        }

        .button--back .button__label {
            font-size: 14px;
            font-weight: 500;
            color: #fff;
        }

        .titleEditor__preview {
            position: relative;
            left: 100px;
        }

        @media screen and (max-width: 768px) {
            .button--back {
                left: 20px;
            }
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('extra_js_head'); ?>
    <?php if(app()->isProduction()): ?>
        <link href="<?php echo e(twillAsset('main-form.js')); ?>" rel="preload" as="script" crossorigin />
    <?php endif; ?>
<?php $__env->stopPush(); ?>

<?php
    $editor = $editor ?? false;
    $translate = $translate ?? false;
    $translateTitle = $translateTitle ?? ($translate ?? false);
    $titleFormKey = $titleFormKey ?? 'title';
    $customForm = $customForm ?? false;
    $controlLanguagesPublication = $controlLanguagesPublication ?? true;
    $disableContentFieldset = $disableContentFieldset ?? false;
    $editModalTitle = $createWithoutModal ?? false ? twillTrans('twill::lang.modal.create.title') : null;
    $item = isset($item) ? $item : null;

    // TODO: cache and move out of view
    if (config('twill.enabled.permissions-management')) {
        $users = app()->make('A17\Twill\Repositories\UserRepository')->published()->notSuperAdmin()->get();
        $groups = app()
            ->make('A17\Twill\Repositories\GroupRepository')
            ->get()
            ->map(function ($group) {
                return [
                    'name' => $group->id . '_group_authorized',
                    'value' => $group->id,
                    'label' => $group->name,
                ];
            });
    }
?>

<?php $__env->startSection('content'); ?>
    <div class="form" v-sticky data-sticky-id="navbar" data-sticky-offset="0" data-sticky-topoffset="12">


        <div class="navbar navbar--sticky" data-sticky-top="navbar">
            <a href="<?php echo e(url()->previous() ?? route('twill.dashboard')); ?>" class="button button--back">
                <span class="icon icon--pagination_left"><svg>
                        <title>dropdown_module</title>
                        <use xlink:href="#icon--pagination_left"></use>
                    </svg></span>
                <span class="button__label">Back</span>
            </a>
            <?php
                $additionalFieldsets =
                    $additionalFieldsets ?? (isset($formBuilder) ? $formBuilder->getAdditionalFieldsets() : []);
                if (!$disableContentFieldset && isset($formBuilder) && $formBuilder->hasFieldsInBaseFieldset()) {
                    array_unshift($additionalFieldsets, [
                        'fieldset' => 'content',
                        'label' => $contentFieldsetLabel ?? twillTrans('twill::lang.form.content'),
                    ]);
                }
            ?>
            <a17-sticky-nav data-sticky-target="navbar" :items="<?php echo e(json_encode($additionalFieldsets)); ?>">
                <a17-title-editor name="<?php echo e($titleFormKey); ?>" thumbnail="<?php echo e($titleThumbnail ?? ''); ?>"
                    :editable-title="<?php echo e(json_encode($editableTitle ?? true)); ?>"
                    :control-languages-publication="<?php echo e(json_encode($controlLanguagesPublication)); ?>"
                    custom-title="<?php echo e($customTitle ?? ''); ?>" custom-permalink="<?php echo e($customPermalink ?? ''); ?>"
                    localized-permalinkbase="<?php echo e(json_encode($localizedPermalinkBase ?? '')); ?>"
                    localized-custom-permalink="<?php echo e(json_encode($localizedCustomPermalink ?? '')); ?>" slot="title"
                    <?php if($createWithoutModal ?? false): ?> :show-modal="true" <?php endif; ?>
                    <?php if(isset($editModalTitle)): ?> modal-title="<?php echo e($editModalTitle); ?>" <?php endif; ?>>
                    <template slot="modal-form">
                        <?php
            if( view()->exists(twillViewName($moduleName ?? null, 'create'))) {
                echo $__env->make(twillViewName($moduleName ?? null, 'create'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->with([])->render();
            } elseif( view()->exists('twill.partials.create')) {
                echo $__env->make('twill.partials.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->with([])->render();
            } elseif( view()->exists('twill::'.$moduleName ?? null.'.create')) {
                echo $__env->make('twill::'.$moduleName ?? null.'.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->with([])->render();
            } elseif( view()->exists('twill::partials.create')) {
                echo $__env->make('twill::partials.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->with([])->render();
            }
            ?>
                    </template>
                </a17-title-editor>

                <div slot="actions">
                    <a17-langswitcher :all-published="<?php echo e(json_encode(!$controlLanguagesPublication)); ?>"></a17-langswitcher>
                    <a17-button v-if="editor" type="button" variant="editor" size="small" @click="openEditor(-1)">
                        <span v-svg symbol="editor"></span><?php echo e(twillTrans('twill::lang.form.editor')); ?>

                    </a17-button>
                </div>

            </a17-sticky-nav>

        </div>
        <form action="<?php echo e($saveUrl); ?>" novalidate method="POST"
            <?php if($customForm): ?> ref="customForm"
              <?php else: ?> v-on:submit.prevent="submitForm" <?php endif; ?>>
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
            <div>
                <div class="container">

                    <div class="wrapper wrapper--reverse" v-sticky data-sticky-id="publisher" data-sticky-offset="80">
                        <aside class="col col--aside">
                            <div class="publisher" data-sticky-target="publisher">
                                <a17-publisher <?php echo !empty($publishDateDisplayFormat) ? "date-display-format='{$publishDateDisplayFormat}'" : ''; ?> <?php echo !empty($publishDateFormat) ? "date-format='{$publishDateFormat}'" : ''; ?> <?php echo !empty($publishDate24Hr) && $publishDate24Hr ? ':date_24h="true"' : ''; ?>

                                    :show-languages="<?php echo e(json_encode($controlLanguagesPublication)); ?>">
                                    <?php echo $__env->yieldContent('publisherRows'); ?>
                                </a17-publisher>
                                <a17-page-nav placeholder="Go to page" previous-url="<?php echo e($parentPreviousUrl ?? ''); ?>"
                                    next-url="<?php echo e($parentNextUrl ?? ''); ?>"></a17-page-nav>

                                <?php if(isset($formBuilder) && $formBuilder->hasSideForm()): ?>
                                    <?php echo $formBuilder->renderSideForm(); ?>

                                <?php else: ?>
                                    <?php if (! empty(trim($__env->yieldContent('sideFieldset')))): ?>
                                        <?php if (isset($component)) { $__componentOriginal4a91a49b910fa85bc29cab966448c662 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4a91a49b910fa85bc29cab966448c662 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'twill::partials.form.utils._fieldset','data' => ['id' => 'options','title' => ''.e($sideFieldsetLabel ?? 'Options').'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('twill::formFieldset'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'options','title' => ''.e($sideFieldsetLabel ?? 'Options').'']); ?>
                                            <?php echo $__env->yieldContent('sideFieldset'); ?>
                                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4a91a49b910fa85bc29cab966448c662)): ?>
<?php $attributes = $__attributesOriginal4a91a49b910fa85bc29cab966448c662; ?>
<?php unset($__attributesOriginal4a91a49b910fa85bc29cab966448c662); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4a91a49b910fa85bc29cab966448c662)): ?>
<?php $component = $__componentOriginal4a91a49b910fa85bc29cab966448c662; ?>
<?php unset($__componentOriginal4a91a49b910fa85bc29cab966448c662); ?>
<?php endif; ?>
                                    <?php endif; ?>
                                    <?php echo $__env->yieldContent('sideFieldsets'); ?>
                                <?php endif; ?>
                            </div>
                        </aside>
                        <section class="col col--primary" data-sticky-top="publisher">
                            <?php if(isset($formBuilder) && $formBuilder->hasForm()): ?>
                                <?php echo $formBuilder->renderBaseForm(); ?>

                            <?php else: ?>
                                <?php if (! ($disableContentFieldset)): ?>
                                    <?php if (isset($component)) { $__componentOriginal4a91a49b910fa85bc29cab966448c662 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4a91a49b910fa85bc29cab966448c662 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'twill::partials.form.utils._fieldset','data' => ['id' => 'content','title' => ''.e($contentFieldsetLabel ?? twillTrans('twill::lang.form.content')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('twill::formFieldset'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'content','title' => ''.e($contentFieldsetLabel ?? twillTrans('twill::lang.form.content')).'']); ?>
                                        <?php echo $__env->yieldContent('contentFields'); ?>
                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4a91a49b910fa85bc29cab966448c662)): ?>
<?php $attributes = $__attributesOriginal4a91a49b910fa85bc29cab966448c662; ?>
<?php unset($__attributesOriginal4a91a49b910fa85bc29cab966448c662); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4a91a49b910fa85bc29cab966448c662)): ?>
<?php $component = $__componentOriginal4a91a49b910fa85bc29cab966448c662; ?>
<?php unset($__componentOriginal4a91a49b910fa85bc29cab966448c662); ?>
<?php endif; ?>
                                <?php endif; ?>

                                <?php echo $__env->yieldContent('fieldsets'); ?>
                            <?php endif; ?>

                            <?php if(\A17\Twill\Facades\TwillPermissions::levelIs(\A17\Twill\Enums\PermissionLevel::LEVEL_ROLE_GROUP_ITEM)): ?>
                                <?php if($showPermissionFieldset ?? null): ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-item', isset($item) ? $item : null)): ?>
                                        <?php if (isset($component)) { $__componentOriginal4a91a49b910fa85bc29cab966448c662 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4a91a49b910fa85bc29cab966448c662 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'twill::partials.form.utils._fieldset','data' => ['id' => 'permissions','title' => 'User Permissions','open' => false]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('twill::formFieldset'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'permissions','title' => 'User Permissions','open' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false)]); ?>
                                            <?php if (isset($component)) { $__componentOriginald46de9af0367c054281992115c9da5ac = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald46de9af0367c054281992115c9da5ac = $attributes; } ?>
<?php $component = A17\Twill\View\Components\Fields\SelectPermissions::resolve(['itemsInSelectsTables' => $users,'labelKey' => 'name','namePattern' => 'user_%id%_permission','listUser' => true] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('twill::select-permissions'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\A17\Twill\View\Components\Fields\SelectPermissions::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald46de9af0367c054281992115c9da5ac)): ?>
<?php $attributes = $__attributesOriginald46de9af0367c054281992115c9da5ac; ?>
<?php unset($__attributesOriginald46de9af0367c054281992115c9da5ac); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald46de9af0367c054281992115c9da5ac)): ?>
<?php $component = $__componentOriginald46de9af0367c054281992115c9da5ac; ?>
<?php unset($__componentOriginald46de9af0367c054281992115c9da5ac); ?>
<?php endif; ?>
                                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4a91a49b910fa85bc29cab966448c662)): ?>
<?php $attributes = $__attributesOriginal4a91a49b910fa85bc29cab966448c662; ?>
<?php unset($__attributesOriginal4a91a49b910fa85bc29cab966448c662); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4a91a49b910fa85bc29cab966448c662)): ?>
<?php $component = $__componentOriginal4a91a49b910fa85bc29cab966448c662; ?>
<?php unset($__componentOriginal4a91a49b910fa85bc29cab966448c662); ?>
<?php endif; ?>
                                    <?php endif; ?>
                                <?php endif; ?>
                            <?php endif; ?>
                        </section>
                    </div>
                </div>
            </div>
            <a17-spinner v-if="loading"></a17-spinner>
        </form>
    </div>
    <a17-modal class="modal--browser" ref="browser" mode="medium" :force-close="true">
        <a17-browser></a17-browser>
    </a17-modal>
    <a17-modal class="modal--browser" ref="browserWide" mode="wide" :force-close="true">
        <a17-browser></a17-browser>
    </a17-modal>
    <a17-editor v-if="editor" ref="editor"
        bg-color="<?php echo e(config('twill.block_editor.background_color') ?? '#FFFFFF'); ?>"></a17-editor>
    <a17-previewer ref="preview"
        :breakpoints-config="<?php echo e(json_encode(config('twill.preview.breakpoints'))); ?>"></a17-previewer>
    <a17-dialog ref="warningContentEditor" modal-title="<?php echo e(twillTrans('twill::lang.form.dialogs.delete.title')); ?>"
        confirm-label="<?php echo e(twillTrans('twill::lang.form.dialogs.delete.confirm')); ?>">
        <p class="modal--tiny-title">
            <strong><?php echo e(twillTrans('twill::lang.form.dialogs.delete.delete-content')); ?></strong>
        </p>
        <p><?php echo twillTrans('twill::lang.form.dialogs.delete.confirmation'); ?></p>
    </a17-dialog>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('initialStore'); ?>
    window['<?php echo e(config('twill.js_namespace')); ?>'].STORE.form = {
    baseUrl: '<?php echo e($baseUrl ?? ''); ?>',
    saveUrl: '<?php echo e($saveUrl); ?>',
    previewUrl: '<?php echo e($previewUrl ?? ''); ?>',
    restoreUrl: '<?php echo $restoreUrl ?? ''; ?>',
    availableBlocks: {},
    blocks: {},
    blockPreviewUrl: '<?php echo e($blockPreviewUrl ?? ''); ?>',
    repeaters: <?php echo json_encode(($form_fields['repeaters'] ?? []) + ($form_fields['blocksRepeaters'] ?? [])); ?>,
    fields: [],
    editor: <?php echo e($editor ? 'true' : 'false'); ?>,
    isCustom: <?php echo e($customForm ? 'true' : 'false'); ?>,
    reloadOnSuccess: <?php echo e($reloadOnSuccess ?? false ? 'true' : 'false'); ?>,
    editorNames: []
    }

    window['<?php echo e(config('twill.js_namespace')); ?>'].STORE.publication = {
    withPublicationToggle: <?php echo e(json_encode(($publish ?? true) && $item?->isFillable('published'))); ?>,
    published: <?php echo e($item?->published ? 'true' : 'false'); ?>,
    createWithoutModal: <?php echo e(isset($createWithoutModal) && $createWithoutModal ? 'true' : 'false'); ?>,
    withPublicationTimeframe: <?php echo e(json_encode(($schedule ?? true) && $item?->isFillable('publish_start_date'))); ?>,
    publishedLabel: '<?php echo e($publishedLabel ?? twillTrans('twill::lang.main.published')); ?>',
    draftLabel: '<?php echo e($draftLabel ?? twillTrans('twill::lang.main.draft')); ?>',
    expiredLabel: '<?php echo e(twillTrans('twill::lang.publisher.expired')); ?>',
    scheduledLabel: '<?php echo e(twillTrans('twill::lang.publisher.scheduled')); ?>',
    submitDisableMessage: '<?php echo e($submitDisableMessage ?? ''); ?>',
    startDate: '<?php echo e($item?->publish_start_date ?? ''); ?>',
    endDate: '<?php echo e($item?->publish_end_date ?? ''); ?>',
    visibility: '<?php echo e($item?->isFillable('public') ? ($item?->public ? 'public' : 'private') : false); ?>',
    reviewProcess: <?php echo isset($reviewProcess) ? json_encode($reviewProcess) : '[]'; ?>,
    submitOptions: <?php echo isset($submitOptions) ? json_encode($submitOptions) : 'null'; ?>

    }

    window['<?php echo e(config('twill.js_namespace')); ?>'].STORE.revisions = <?php echo json_encode($revisions ?? []); ?>


    window['<?php echo e(config('twill.js_namespace')); ?>'].STORE.parentId = <?php echo e($item?->parent_id ?? 0); ?>

    window['<?php echo e(config('twill.js_namespace')); ?>'].STORE.parents = <?php echo json_encode($parents ?? []); ?>


    <?php if(isset($item) && classHasTrait($item, \A17\Twill\Models\Behaviors\HasMedias::class)): ?>
        window['<?php echo e(config('twill.js_namespace')); ?>'].STORE.medias.crops = <?php echo json_encode(
            $item->getMediasParams() +
                \A17\Twill\Facades\TwillBlocks::getAllCropConfigs(true) +
                (config('twill.settings.crops') ?? []),
        ); ?>

    <?php else: ?>
        window['<?php echo e(config('twill.js_namespace')); ?>'].STORE.medias.crops = <?php echo json_encode(
            \A17\Twill\Facades\TwillBlocks::getAllCropConfigs(true) + (config('twill.settings.crops') ?? []),
        ); ?>

    <?php endif; ?>
    window['<?php echo e(config('twill.js_namespace')); ?>'].STORE.medias.selected = {}

    window['<?php echo e(config('twill.js_namespace')); ?>'].STORE.browser = {}
    window['<?php echo e(config('twill.js_namespace')); ?>'].STORE.browser.selected = {}

    window['<?php echo e(config('twill.js_namespace')); ?>'].APIKEYS = {
    'googleMapApi': '<?php echo e(config('twill.google_maps_api_key')); ?>'
    }

    
    window['<?php echo e(config('twill.js_namespace')); ?>'].STORE.groups = <?php echo isset($groups) ? json_encode($groups) : '[]'; ?>;
    window['<?php echo e(config('twill.js_namespace')); ?>'].STORE.groupUserMapping = <?php echo isset($groupUserMapping) ? json_encode($groupUserMapping) : '[]'; ?>;
<?php $__env->stopSection(); ?>

<?php $__env->startPrepend('extra_js'); ?>
    <?php echo $__env->renderWhen(config('twill.block_editor.inline_blocks_templates', true),
        'twill::partials.form.utils._blocks_templates', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
    <script src="<?php echo e(twillAsset('main-form.js')); ?>" crossorigin></script>
    <script>
        const groupUserMapping = <?php echo isset($groupUserMapping) ? json_encode($groupUserMapping) : '[]'; ?>;
        window['<?php echo e(config('twill.js_namespace')); ?>'].vm.$store.subscribe((mutation, state) => {
            if (mutation.type === 'updateFormField' && mutation.payload.name.endsWith('group_authorized')) {
                const groupId = mutation.payload.name.replace('_group_authorized', '')
                const checked = mutation.payload.value
                if (!isNaN(groupId)) {
                    const users = groupUserMapping[groupId]
                    users.forEach(function(userId) {
                        // If the user's permission is <= view, it will be updated
                        const currentPermission = state['form']['fields'].find(function(e) {
                            return e.name == `user_${userId}_permission`
                        }).value
                        if (currentPermission === '' || currentPermission === 'view-item') {
                            const field = {
                                name: `user_${userId}_permission`,
                                value: checked ? 'view-item' : ''
                            }
                            window['<?php echo e(config('twill.js_namespace')); ?>'].vm.$store.commit(
                                'updateFormField', field)
                        }
                    })
                }
            }
        })
    </script>
<?php $__env->stopPrepend(); ?>

<?php echo $__env->make('twill::layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/medera-cms/resources/views/vendor/twill/layouts/form.blade.php ENDPATH**/ ?>