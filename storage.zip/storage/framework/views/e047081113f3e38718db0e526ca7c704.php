<h1 class="header__title">
    <a href=<?php echo e(config('twill.enabled.dashboard') ? route(config('twill.admin_route_name_prefix') . 'dashboard') : '#'); ?>>
        <?php echo e(config('app.name')); ?>

        <span class="envlabel">
            <?php echo e(app()->environment() === 'production' ? 'prod' : app()->environment()); ?>

        </span>
    </a>
</h1>
<?php /**PATH /var/www/medera-cms/resources/views/vendor/twill/partials/navigation/_title.blade.php ENDPATH**/ ?>