<header class="headerMobile" data-header-mobile>
    <nav class="headerMobile__nav">
        <div class="container">
            <?php if (isset($component)) { $__componentOriginal5512557211bcf4a5508ae7a591e8395e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5512557211bcf4a5508ae7a591e8395e = $attributes; } ?>
<?php $component = A17\Twill\View\Components\Partials\Navigation\Title::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('twill.partials::navigation.title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\A17\Twill\View\Components\Partials\Navigation\Title::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5512557211bcf4a5508ae7a591e8395e)): ?>
<?php $attributes = $__attributesOriginal5512557211bcf4a5508ae7a591e8395e; ?>
<?php unset($__attributesOriginal5512557211bcf4a5508ae7a591e8395e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5512557211bcf4a5508ae7a591e8395e)): ?>
<?php $component = $__componentOriginal5512557211bcf4a5508ae7a591e8395e; ?>
<?php unset($__componentOriginal5512557211bcf4a5508ae7a591e8395e); ?>
<?php endif; ?>
            <div class="headerMobile__list">
                <?php $__currentLoopData = $linkGroups['left']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $link->render('mobile'); ?> <br />
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="headerMobile__list">
                <?php $__currentLoopData = $linkGroups['right']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $link->render('mobile'); ?><br />
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if(($currentUser = auth()->user()) && config('twill.enabled.users-management')): ?>
                    <a
                        href="<?php echo e(route(config('twill.admin_route_name_prefix') . 'users.index')); ?>"><?php echo e(twillTrans('twill::lang.nav.cms-users')); ?></a><br />
                    <a
                        href="<?php echo e(route(config('twill.admin_route_name_prefix') . 'users.edit', $currentUser->id)); ?>"><?php echo e(twillTrans('twill::lang.nav.profile')); ?></a><br />
                    <a href="#" data-logout-btn><?php echo e(twillTrans('twill::lang.nav.logout')); ?></a>
                <?php endif; ?>
            </div>
        </div>
    </nav>
</header>

<button class="ham <?php if(isset($search) && $search): ?> ham--search <?php endif; ?>" data-ham-btn>
    <?php if($active_title): ?>
        <span class="ham__label"><?php echo e($active_title); ?></span>
    <?php endif; ?>
    <span class="btn ham__btn">
        <span class="ham__icon">
            <span class="ham__line"></span>
        </span>
        <span class="icon icon--close_modal"><svg>
                <title><?php echo e(twillTrans('twill::lang.nav.close-menu')); ?></title>
                <use xlink:href="#icon--close_modal"></use>
            </svg></span>
    </span>
</button>
<?php /**PATH /var/www/medera-cms/resources/views/vendor/twill/partials/navigation/_overlay_navigation.blade.php ENDPATH**/ ?>