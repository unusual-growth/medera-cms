<?php
$contact_information = TwillAppSettings::getTranslated('footer-settings.contact.contact-information');
?>

<footer>
    <div class="row-top">
        <div class="container xlarge">
            <div class="row">
                <div class="col-sm-3 left">
                    <a href="/" class="logo">
                        <img src="<?php echo e($logos->image('footer-logo')); ?>" alt="<?php echo e($logos->imageAltText('footer-logo')); ?>">
                    </a>

                    
                    <div class="socials">
                        <p>FOLLOW US</p>
                        <div>
                            <?php $__currentLoopData = $social_links_block; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $repeaterItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a target="_blank" href="<?php echo e($repeaterItem->input('url')); ?>">
                                <?php
                                  $image = $repeaterItem->image('social-media-icon', 'default');

                                ?>
                              <img src="<?php echo e($image); ?>" alt="icon" />
                            </a>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </div>
                    </div>
                </div>
                <div class="col-sm-3 mid-left">
                    <p><?php echo e(__('frontend.Product')); ?></p>
                    <?php if (isset($component)) { $__componentOriginaldadc8f6aa159c05f9151bf94d661e8e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldadc8f6aa159c05f9151bf94d661e8e3 = $attributes; } ?>
<?php $component = App\View\Components\Menu::resolve(['location' => 'footer'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Menu::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldadc8f6aa159c05f9151bf94d661e8e3)): ?>
<?php $attributes = $__attributesOriginaldadc8f6aa159c05f9151bf94d661e8e3; ?>
<?php unset($__attributesOriginaldadc8f6aa159c05f9151bf94d661e8e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldadc8f6aa159c05f9151bf94d661e8e3)): ?>
<?php $component = $__componentOriginaldadc8f6aa159c05f9151bf94d661e8e3; ?>
<?php unset($__componentOriginaldadc8f6aa159c05f9151bf94d661e8e3); ?>
<?php endif; ?>
                </div>

                <?php
                    $list2 = [
                        [
                            'text' => 'Packaging',
                        ],
                        [
                            'text' => 'Shipping & Returns',
                        ],
                        [
                            'text' => 'FAQ',
                        ],
                        [
                            'text' => 'Feedback',
                        ],
                    ];
                ?>
                <div class="col-sm-3 mid-right">
                    <p><?php echo e(__('frontend.LearnMore')); ?></p>
                    <?php if (isset($component)) { $__componentOriginaldadc8f6aa159c05f9151bf94d661e8e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldadc8f6aa159c05f9151bf94d661e8e3 = $attributes; } ?>
<?php $component = App\View\Components\Menu::resolve(['location' => 'footer2'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Menu::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldadc8f6aa159c05f9151bf94d661e8e3)): ?>
<?php $attributes = $__attributesOriginaldadc8f6aa159c05f9151bf94d661e8e3; ?>
<?php unset($__attributesOriginaldadc8f6aa159c05f9151bf94d661e8e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldadc8f6aa159c05f9151bf94d661e8e3)): ?>
<?php $component = $__componentOriginaldadc8f6aa159c05f9151bf94d661e8e3; ?>
<?php unset($__componentOriginaldadc8f6aa159c05f9151bf94d661e8e3); ?>
<?php endif; ?>

                </div>
              
                <div class="col-sm-3 right">
                    <?php echo $contact_information; ?>

                    
                </div>
            </div>

        
        </div>
    </div>

    <div class="container ful-1440 line">
        <div class="container xlarge">
            <div class="row justify-space-between">
                <div class="bottom">
                    <div class="__left">
                        <span>©2024 Medera Nutrition. <?php echo e(__('frontend.AllRightReserved')); ?>.</span>
                    </div>
                    <div class="__right">
                        <?php if (isset($component)) { $__componentOriginaldadc8f6aa159c05f9151bf94d661e8e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldadc8f6aa159c05f9151bf94d661e8e3 = $attributes; } ?>
<?php $component = App\View\Components\Menu::resolve(['location' => 'footer3'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Menu::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldadc8f6aa159c05f9151bf94d661e8e3)): ?>
<?php $attributes = $__attributesOriginaldadc8f6aa159c05f9151bf94d661e8e3; ?>
<?php unset($__attributesOriginaldadc8f6aa159c05f9151bf94d661e8e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldadc8f6aa159c05f9151bf94d661e8e3)): ?>
<?php $component = $__componentOriginaldadc8f6aa159c05f9151bf94d661e8e3; ?>
<?php unset($__componentOriginaldadc8f6aa159c05f9151bf94d661e8e3); ?>
<?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

</footer><?php /**PATH /var/www/medera-cms/resources/views/site/layouts/footer.blade.php ENDPATH**/ ?>