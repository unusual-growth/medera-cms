window['<?php echo e(config('twill.js_namespace')); ?>'].STORE.form.blocks = <?php echo json_encode($form_fields['blocks'] ?? (object)[]); ?>


<?php $__currentLoopData = $form_fields['blocksFields'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    window['<?php echo e(config('twill.js_namespace')); ?>'].STORE.form.fields.push(<?php echo json_encode($field); ?>)
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__currentLoopData = $form_fields['blocksMedias'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $medias): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    window['<?php echo e(config('twill.js_namespace')); ?>'].STORE.medias.selected["<?php echo e($name); ?>"] =
    <?php echo json_encode($medias); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__currentLoopData = $form_fields['blocksFiles'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $files): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    window['<?php echo e(config('twill.js_namespace')); ?>'].STORE.medias.selected["<?php echo e($name); ?>"] =
    <?php echo json_encode($files); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__currentLoopData = $form_fields['blocksBrowsers'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $browser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    window['<?php echo e(config('twill.js_namespace')); ?>'].STORE.browser.selected["<?php echo e($name); ?>"] =
    <?php echo json_encode($browser); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH /var/www/medera-cms/resources/views/vendor/twill/partials/form/utils/_block_editor_store.blade.php ENDPATH**/ ?>