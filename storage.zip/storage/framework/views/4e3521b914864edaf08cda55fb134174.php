<?php if($activeSyntax): ?>
    <?php if (! $__env->hasRenderedOnce('form:wysiwyg')): $__env->markAsRenderedOnce('form:wysiwyg');
$__env->startPush('extra_css'); ?>
        <link rel="stylesheet" href="//cdn.jsdelivr.net/gh/highlightjs/cdn-release@9.12.0/build/styles/<?php echo e($theme); ?>.min.css">
    <?php $__env->stopPush(); endif; ?>
<?php endif; ?>

<?php if($type === 'tiptap'): ?>
    <?php if($translated): ?>
        <a17-locale
            type="a17-wysiwyg-tiptap"
            :attributes="{
            label: '<?php echo e($label); ?>',
            <?php echo $formFieldName(true); ?>,
            <?php if($note): ?> note: '<?php echo e($note); ?>', <?php endif; ?>
            <?php if($required): ?> required: true, <?php endif; ?>
            <?php if($options): ?> options: <?php echo e(json_encode($options)); ?>, <?php endif; ?>
            <?php if($placeholder): ?> placeholder: '<?php echo e(addslashes($placeholder)); ?>', <?php endif; ?>
            <?php if($direction): ?> direction: '<?php echo e($direction); ?>', <?php endif; ?>
            <?php if($maxlength): ?> maxlength: <?php echo e($maxlength); ?>, <?php endif; ?>
            <?php if($hideCounter): ?> showCounter: false, <?php endif; ?>
            <?php if($disabled): ?> disabled: true, <?php endif; ?>
            <?php if($readOnly): ?> readonly: true, <?php endif; ?>
            <?php if($editSource): ?> editSource: true, <?php endif; ?>
            <?php if($inModal): ?> inModal: true, <?php endif; ?>
            <?php if($limitHeight): ?> limitHeight: true, <?php endif; ?>
            <?php if($endpoints): ?> browserEndpoints: <?php echo e(json_encode($endpoints)); ?>, <?php endif; ?>
            <?php if($classList): ?> classList: <?php echo e(json_encode($classList)); ?>, <?php endif; ?>
            <?php if($default): ?>
                initialValue: '<?php echo e($default); ?>',
                hasDefaultStore: true,
            <?php endif; ?>
                inStore: 'value'
            }"
        ></a17-locale>
    <?php else: ?>
        <a17-wysiwyg-tiptap
            label="<?php echo e($label); ?>"
            <?php echo $formFieldName(); ?>

            <?php if($note): ?> note="<?php echo e($note); ?>" <?php endif; ?>
            <?php if($required): ?> :required="true" <?php endif; ?>
            <?php if($options): ?> :options='<?php echo json_encode($options); ?>' <?php endif; ?>
            <?php if($placeholder): ?> placeholder='<?php echo e($placeholder); ?>' <?php endif; ?>
            <?php if($direction): ?> direction="<?php echo e($direction); ?>" <?php endif; ?>
            <?php if($maxlength): ?> :maxlength='<?php echo e($maxlength); ?>' <?php endif; ?>
            <?php if($hideCounter): ?> :showCounter='false' <?php endif; ?>
            <?php if($disabled): ?> disabled <?php endif; ?>
            <?php if($readOnly): ?> readonly <?php endif; ?>
            <?php if($editSource): ?> :edit-source='true' <?php endif; ?>
            <?php if($limitHeight): ?> :limit-height='true' <?php endif; ?>
            <?php if($endpoints): ?> :browser-endpoints='<?php echo json_encode($endpoints); ?>' <?php endif; ?>
            <?php if($classList): ?> :class-list='<?php echo json_encode($classList); ?>' <?php endif; ?>
            <?php if($default): ?>
            :initial-value="'<?php echo e($default); ?>'"
            :has-default-store="true"
            <?php endif; ?>
            <?php if($inModal): ?> :in-modal="true" <?php endif; ?>
            in-store="value"
        ></a17-wysiwyg-tiptap>
    <?php endif; ?>
<?php else: ?>
    <?php if($translated): ?>
        <a17-locale
            type="a17-wysiwyg"
            :attributes="{
            label: '<?php echo e($label); ?>',
            <?php echo $formFieldName(true); ?>,
            <?php if($note): ?> note: '<?php echo e($note); ?>', <?php endif; ?>
            <?php if($required): ?> required: true, <?php endif; ?>
            <?php if($options): ?> options: <?php echo e(json_encode($options)); ?>, <?php endif; ?>
            <?php if($placeholder): ?> placeholder: '<?php echo e(addslashes($placeholder)); ?>', <?php endif; ?>
            <?php if($direction): ?> direction: '<?php echo e($direction); ?>', <?php endif; ?>
            <?php if($maxlength): ?> maxlength: <?php echo e($maxlength); ?>, <?php endif; ?>
            <?php if($hideCounter): ?> showCounter: false, <?php endif; ?>
            <?php if($disabled): ?> disabled: true, <?php endif; ?>
            <?php if($readOnly): ?> readonly: true, <?php endif; ?>
            <?php if($editSource): ?> editSource: true, <?php endif; ?>
            <?php if($inModal): ?> inModal: true, <?php endif; ?>
            <?php if($limitHeight): ?> limitHeight: true, <?php endif; ?>
            <?php if($default): ?>
                initialValue: '<?php echo e($default); ?>',
                hasDefaultStore: true,
            <?php endif; ?>
                inStore: 'value'
            }"
        ></a17-locale>
    <?php else: ?>
        <a17-wysiwyg
            label="<?php echo e($label); ?>"
            <?php echo $formFieldName(); ?>

            <?php if($note): ?> note="<?php echo e($note); ?>" <?php endif; ?>
            <?php if($required): ?> :required="true" <?php endif; ?>
            <?php if($options): ?> :options='<?php echo json_encode($options); ?>' <?php endif; ?>
            <?php if($placeholder): ?> placeholder='<?php echo e($placeholder); ?>' <?php endif; ?>
            <?php if($direction): ?> direction="<?php echo e($direction); ?>" <?php endif; ?>
            <?php if($maxlength): ?> :maxlength='<?php echo e($maxlength); ?>' <?php endif; ?>
            <?php if($hideCounter): ?> :showCounter='false' <?php endif; ?>
            <?php if($disabled): ?> disabled <?php endif; ?>
            <?php if($readOnly): ?> readonly <?php endif; ?>
            <?php if($editSource): ?> :edit-source='true' <?php endif; ?>
            <?php if($limitHeight): ?> :limit-height='true' <?php endif; ?>
            <?php if($default): ?>
            :initial-value="'<?php echo e($default); ?>'"
            :has-default-store="true"
            <?php endif; ?>
            <?php if($inModal): ?> :in-modal="true" <?php endif; ?>
            in-store="value"
        ></a17-wysiwyg>
    <?php endif; ?>

<?php endif; ?>

<?php if (! ($renderForBlocks || $renderForModal)): ?>
    <?php $__env->startPush('vuexStore'); ?>
        <?php echo $__env->make('twill::partials.form.utils._translatable_input_store', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->stopPush(); ?>
<?php endif; ?>
<?php /**PATH /var/www/medera-cms/resources/views/vendor/twill/partials/form/_wysiwyg.blade.php ENDPATH**/ ?>