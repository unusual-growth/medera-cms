<?php if(isset($sources) && count($sources) > 1): ?>
    <picture>
        <?php if(isset($sources)): ?>
            <?php $__currentLoopData = $sources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $source): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <source
                    <?php if(isset($source['type']) && config('twill-image.webp_support')): ?>
                        type="<?php echo e($source['type']); ?>"
                    <?php endif; ?>
                    <?php if(isset($source['mediaQuery'])): ?>
                        media="<?php echo e($source['mediaQuery']); ?>"
                    <?php endif; ?>
                    srcset="<?php echo e($source['srcset']); ?>"
                    <?php if(isset($sizes)): ?>
                        sizes="<?php echo e($sizes); ?>"
                    <?php endif; ?>
                />
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

        <?php echo $__env->make('twill-image::image', [
            'src' => $fallback,
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </picture>
<?php elseif(count($sources) === 1): ?>
    <?php
    $source = $sources[0];
    ?>

    <?php echo $__env->make('twill-image::image', [
        'src' => $fallback,
        'type' => isset($source['type']) && config('twill-image.webp_support') ? $source['type'] : null,
        'media' => isset($source['mediaQuery']) ? $source['mediaQuery'] : null,
        'srcSet' => $source['srcset'],
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
    <?php echo $__env->make('twill-image::image', [
        'src' => $fallback,
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<?php /**PATH /var/www/medera-cms/vendor/area17/twill-image/src/../resources/views/picture.blade.php ENDPATH**/ ?>