<?php $__env->startSection('content'); ?>
<?php echo $item->renderBlocks(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/medera-cms/resources/views/site/butyrate.blade.php ENDPATH**/ ?>