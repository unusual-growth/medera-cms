<?php if (isset($component)) { $__componentOriginal4621378c88da6151a5fb60ddab252e61 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4621378c88da6151a5fb60ddab252e61 = $attributes; } ?>
<?php $component = A17\Twill\View\Components\Fields\Medias::resolve(['name' => $name,'label' => $label,'fieldNote' => $fieldNote] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('twill::medias'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\A17\Twill\View\Components\Fields\Medias::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4621378c88da6151a5fb60ddab252e61)): ?>
<?php $attributes = $__attributesOriginal4621378c88da6151a5fb60ddab252e61; ?>
<?php unset($__attributesOriginal4621378c88da6151a5fb60ddab252e61); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4621378c88da6151a5fb60ddab252e61)): ?>
<?php $component = $__componentOriginal4621378c88da6151a5fb60ddab252e61; ?>
<?php unset($__componentOriginal4621378c88da6151a5fb60ddab252e61); ?>
<?php endif; ?><?php /**PATH /var/www/medera-cms/storage/framework/views/a3270448c39b85cae5f5ed45e3cf3c67.blade.php ENDPATH**/ ?>