<section class="request-section">
    <?php if(!$block->input('has_title')): ?>
    <div class="container medium">
        <?php echo $__env->make('unusual_form::layouts._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->with(['formData' => config('forms.request-form')])->render(); ?>
    </div>
    <?php else: ?>

    <div class="container xlarge">
        <div class="row">
            <div class="col-md-6 bg-col">
                <p>
                    <?php echo e($block->translatedInput('title')); ?>

                </p>
            </div>
            <div class="col-md-6">
                    <?php echo $__env->make('unusual_form::layouts._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->with(['formData' => config('forms.request-form')])->render(); ?>
                </div>
            </div>
        </div>
    <?php endif; ?>
</section>
<?php /**PATH /var/www/medera-cms/resources/views/components/twill/blocks/requestform.blade.php ENDPATH**/ ?>