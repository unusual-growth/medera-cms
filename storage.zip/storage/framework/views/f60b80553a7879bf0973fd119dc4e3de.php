<!DOCTYPE html>
<html lang="<?php echo e(LaravelLocalization::getCurrentLocale()); ?>">
<?php echo $__env->make('site.meta.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
    
    <?php echo $__env->make('site.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>
     <?php echo $__env->make('site.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
    <?php echo $__env->yieldPushContent('custom-last-script'); ?>
    <?php echo $__env->yieldPushContent('final-scripts'); ?>
</html>
<?php /**PATH /var/www/medera-cms/resources/views/site/layouts/master.blade.php ENDPATH**/ ?>