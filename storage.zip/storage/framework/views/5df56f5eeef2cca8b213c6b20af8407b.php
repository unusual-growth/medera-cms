<a17-singlecheckbox
    <?php echo $formFieldName(); ?>

    label="<?php echo e($label ?? ''); ?>"
    :initial-value="<?php echo e($default ? 'true' : 'false'); ?>"
    <?php if($note): ?> note='<?php echo e($note); ?>' <?php endif; ?>
    <?php if($disabled): ?> disabled <?php endif; ?>
    <?php if($border): ?> :border="true" <?php endif; ?>
    <?php if($requireConfirmation): ?> :require-confirmation="true" <?php endif; ?>
    <?php if($confirmMessageText): ?> confirm-message-text="<?php echo e($confirmMessageText); ?>" <?php endif; ?>
    <?php if($confirmTitleText): ?> confirm-title-text="<?php echo e($confirmTitleText); ?>" <?php endif; ?>
    :has-default-store="true"
    in-store="currentValue"
></a17-singlecheckbox>

<?php if (! ($renderForBlocks || $renderForModal || (!isset($item->$name) && is_null($formFieldsValue = getFormFieldsValue($form_fields, $name))))): ?>
    <?php $__env->startPush('vuexStore'); ?>
        window['<?php echo e(config('twill.js_namespace')); ?>'].STORE.form.fields.push({
        name: '<?php echo e($name); ?>',
        value:
        <?php if((isset($item) && $item->$name) || ($formFieldsValue ?? false)): ?>
            true
        <?php else: ?>
            false
        <?php endif; ?>
        })
    <?php $__env->stopPush(); ?>
<?php endif; ?>
<?php /**PATH /var/www/medera-cms/resources/views/vendor/twill/partials/form/_checkbox.blade.php ENDPATH**/ ?>