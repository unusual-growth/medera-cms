<?php $__env->startSection('input'); ?>


    
    <button
        type="<?php echo e(isset($button_type) ? $button_type : ''); ?>"
        class="custom-submit <?php echo e($class ? $class :''); ?>"
        name="<?php echo e($input_name); ?>"
        id="<?php echo e($input_name); ?>_checkbox"
        value="1"
        <?php echo e($checked ?? ''); ?>

        <?php echo e($props ?? ''); ?>

        >
        <?php echo e(__($text)); ?>

    </button>



<?php $__env->stopSection(true); ?>
<?php echo $__env->make('unusual_form::layouts._input-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/medera-cms/resources/views/vendor/unusual_form/inputs/_button.blade.php ENDPATH**/ ?>