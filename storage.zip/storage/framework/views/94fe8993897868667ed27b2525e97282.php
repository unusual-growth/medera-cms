<?php if( $item->hasMetadata ): ?>
    <?php
$data = eval('return  [
    \'name\' => \'metadata[title]\',
    \'label\' =>  twillTrans(\'twill-metadata::form.fields.title.label\'),
    \'note\' => twillTrans(\'twill-metadata::form.fields.title.note\'),
    \'translated\' => true,
    ];');$fieldAttributes = "";foreach(array_keys($data) as $attribute) {  $fieldAttributes .= " :$attribute='$" . $attribute . "'";}
if ($renderForBlocks ?? false) {  $fieldAttributes .= " :render-for-blocks='true'";}if ($renderForModal ?? false) {  $fieldAttributes .= " :render-for-modal='true'";}$name = "input";echo Blade::render("<x-twill::$name $fieldAttributes />", $data); ?>

    <?php
$data = eval('return  [
    \'name\' => \'metadata[description]\',
    \'label\' => twillTrans(\'twill-metadata::form.fields.description.label\'),
    \'note\' => twillTrans(\'twill-metadata::form.fields.description.note\'),
    \'type\' => \'textarea\',
    \'rows\' => 2,
    \'translated\' => true,
    ];');$fieldAttributes = "";foreach(array_keys($data) as $attribute) {  $fieldAttributes .= " :$attribute='$" . $attribute . "'";}
if ($renderForBlocks ?? false) {  $fieldAttributes .= " :render-for-blocks='true'";}if ($renderForModal ?? false) {  $fieldAttributes .= " :render-for-modal='true'";}$name = "input";echo Blade::render("<x-twill::$name $fieldAttributes />", $data); ?>

    <a17-inputframe>
        <details>
            <summary>
                <span class="f--note f--underlined"><?php echo e(twillTrans('twill-metadata::form.titles.advanced_settings')); ?></span> - <span class="f--small"><?php echo e(twillTrans('twill-metadata::form.titles.advanced_description')); ?></span>
            </summary>

            <?php
$data = eval('return  [
            \'name\' => \'metadata[noindex]\',
            \'label\' => twillTrans(\'twill-metadata::form.fields.noindex.label\'),
            ];');$fieldAttributes = "";foreach(array_keys($data) as $attribute) {  $fieldAttributes .= " :$attribute='$" . $attribute . "'";}
if ($renderForBlocks ?? false) {  $fieldAttributes .= " :render-for-blocks='true'";}if ($renderForModal ?? false) {  $fieldAttributes .= " :render-for-modal='true'";}$name = "checkbox";echo Blade::render("<x-twill::$name $fieldAttributes />", $data); ?>

            <?php
$data = eval('return  [
            \'name\' => \'metadata[nofollow]\',
            \'label\' => twillTrans(\'twill-metadata::form.fields.nofollow.label\'),
            ];');$fieldAttributes = "";foreach(array_keys($data) as $attribute) {  $fieldAttributes .= " :$attribute='$" . $attribute . "'";}
if ($renderForBlocks ?? false) {  $fieldAttributes .= " :render-for-blocks='true'";}if ($renderForModal ?? false) {  $fieldAttributes .= " :render-for-modal='true'";}$name = "checkbox";echo Blade::render("<x-twill::$name $fieldAttributes />", $data); ?>

            <?php
$data = eval('return  [
            \'name\' => \'metadata[canonical_url]\',
            \'label\' => twillTrans(\'twill-metadata::form.fields.canonical_url.label\'),
            \'translated\' => true,
            \'note\' => twillTrans(\'twill-metadata::form.fields.canonical_url.note\'),
            ];');$fieldAttributes = "";foreach(array_keys($data) as $attribute) {  $fieldAttributes .= " :$attribute='$" . $attribute . "'";}
if ($renderForBlocks ?? false) {  $fieldAttributes .= " :render-for-blocks='true'";}if ($renderForModal ?? false) {  $fieldAttributes .= " :render-for-modal='true'";}$name = "input";echo Blade::render("<x-twill::$name $fieldAttributes />", $data); ?>
        </details>
    </a17-inputframe>

    <a17-inputframe>
        <details>
            <summary>
                <span class="f--note f--underlined"><?php echo e(twillTrans('twill-metadata::form.titles.sharing_settings')); ?></span> - <span class="f--small"><?php echo e(twillTrans('twill-metadata::form.titles.sharing_description')); ?></span>
            </summary>

            <?php
$data = eval('return  [
            \'name\' => \'og_image\',
            \'label\' => twillTrans(\'twill-metadata::form.fields.og_image.label\'),
            \'fieldNote\' => twillTrans(\'twill-metadata::form.fields.og_image.note\'),
            ];');$fieldAttributes = "";foreach(array_keys($data) as $attribute) {  $fieldAttributes .= " :$attribute='$" . $attribute . "'";}
if ($renderForBlocks ?? false) {  $fieldAttributes .= " :render-for-blocks='true'";}if ($renderForModal ?? false) {  $fieldAttributes .= " :render-for-modal='true'";}$name = "medias";echo Blade::render("<x-twill::$name $fieldAttributes />", $data); ?>

            <?php
$data = eval('return  [
            \'name\' => \'metadata[og_title]\',
            \'label\' => twillTrans(\'twill-metadata::form.fields.og_title.label\'),
            \'note\' => twillTrans(\'twill-metadata::form.fields.og_title.note\'),
            \'translated\' => true,
            ];');$fieldAttributes = "";foreach(array_keys($data) as $attribute) {  $fieldAttributes .= " :$attribute='$" . $attribute . "'";}
if ($renderForBlocks ?? false) {  $fieldAttributes .= " :render-for-blocks='true'";}if ($renderForModal ?? false) {  $fieldAttributes .= " :render-for-modal='true'";}$name = "input";echo Blade::render("<x-twill::$name $fieldAttributes />", $data); ?>

            <?php
$data = eval('return  [
            \'name\' => \'metadata[og_description]\',
            \'label\' => twillTrans(\'twill-metadata::form.fields.og_description.label\'),
            \'type\' => \'textarea\',
            \'rows\' => 2,
            \'note\' => twillTrans(\'twill-metadata::form.fields.og_description.note\'),
            \'translated\' => true,
            ];');$fieldAttributes = "";foreach(array_keys($data) as $attribute) {  $fieldAttributes .= " :$attribute='$" . $attribute . "'";}
if ($renderForBlocks ?? false) {  $fieldAttributes .= " :render-for-blocks='true'";}if ($renderForModal ?? false) {  $fieldAttributes .= " :render-for-modal='true'";}$name = "input";echo Blade::render("<x-twill::$name $fieldAttributes />", $data); ?>

            <?php if (isset($component)) { $__componentOriginal78d74cb35ff164c647be5f70b0477774 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal78d74cb35ff164c647be5f70b0477774 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'twill::partials.form.utils._columns','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('formColumns'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                 <?php $__env->slot('left', null, []); ?> 
                    <?php
$data = eval('return  [
                    \'name\' => \'metadata[card_type]\',
                    \'label\' => twillTrans(\'twill-metadata::form.fields.og_card_type.label\'),
                    \'placeholder\' => twillTrans(\'twill-metadata::form.fields.og_card_type.placeholder\'),
                    \'options\' => $metadata_card_type_options,
                    ];');$fieldAttributes = "";foreach(array_keys($data) as $attribute) {  $fieldAttributes .= " :$attribute='$" . $attribute . "'";}
if ($renderForBlocks ?? false) {  $fieldAttributes .= " :render-for-blocks='true'";}if ($renderForModal ?? false) {  $fieldAttributes .= " :render-for-modal='true'";}$name = "select";echo Blade::render("<x-twill::$name $fieldAttributes />", $data); ?>
                 <?php $__env->endSlot(); ?>
                 <?php $__env->slot('right', null, []); ?> 
                    <?php
$data = eval('return  [
                    \'name\' => \'metadata[og_type]\',
                    \'label\' => twillTrans(\'twill-metadata::form.fields.og_type.label\'),
                    \'placeholder\' => twillTrans(\'twill-metadata::form.fields.og_type.placeholder\'),
                    \'options\' => $metadata_og_type_options,
                    ];');$fieldAttributes = "";foreach(array_keys($data) as $attribute) {  $fieldAttributes .= " :$attribute='$" . $attribute . "'";}
if ($renderForBlocks ?? false) {  $fieldAttributes .= " :render-for-blocks='true'";}if ($renderForModal ?? false) {  $fieldAttributes .= " :render-for-modal='true'";}$name = "select";echo Blade::render("<x-twill::$name $fieldAttributes />", $data); ?>
                 <?php $__env->endSlot(); ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal78d74cb35ff164c647be5f70b0477774)): ?>
<?php $attributes = $__attributesOriginal78d74cb35ff164c647be5f70b0477774; ?>
<?php unset($__attributesOriginal78d74cb35ff164c647be5f70b0477774); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal78d74cb35ff164c647be5f70b0477774)): ?>
<?php $component = $__componentOriginal78d74cb35ff164c647be5f70b0477774; ?>
<?php unset($__componentOriginal78d74cb35ff164c647be5f70b0477774); ?>
<?php endif; ?>
        </details>
    </a17-inputframe>
<?php endif; ?><?php /**PATH /var/www/medera-cms/resources/views/vendor/twill-metadata/includes/metadata-fields.blade.php ENDPATH**/ ?>