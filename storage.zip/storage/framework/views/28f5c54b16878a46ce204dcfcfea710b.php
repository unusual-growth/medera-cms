<!DOCTYPE html>
<html dir="ltr" lang="<?php echo e(config('twill.locale', 'en')); ?>">

<head>
    <?php echo $__env->make('twill::partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php if(app()->environment('local', 'development') && config('twill.dev_mode', false)): ?>
        <script>
            window.hmr_url = '<?php echo e(config('twill.dev_mode_url', 'http://localhost:8080')); ?>';
        </script>
    <?php endif; ?>
</head>

<body class="env env--<?php echo e(app()->environment()); ?> <?php echo $__env->yieldContent('appTypeClass'); ?>">
    <?php echo $__env->make('twill::partials.icons.svg-sprite', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php if (isset($component)) { $__componentOriginalc01fa8cc1defa953956aed9d4d4701db = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc01fa8cc1defa953956aed9d4d4701db = $attributes; } ?>
<?php $component = A17\Twill\View\Components\Partials\Navigation\Overlay::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('twill.partials::navigation.overlay'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\A17\Twill\View\Components\Partials\Navigation\Overlay::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc01fa8cc1defa953956aed9d4d4701db)): ?>
<?php $attributes = $__attributesOriginalc01fa8cc1defa953956aed9d4d4701db; ?>
<?php unset($__attributesOriginalc01fa8cc1defa953956aed9d4d4701db); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc01fa8cc1defa953956aed9d4d4701db)): ?>
<?php $component = $__componentOriginalc01fa8cc1defa953956aed9d4d4701db; ?>
<?php unset($__componentOriginalc01fa8cc1defa953956aed9d4d4701db); ?>
<?php endif; ?>
    <div class="a17">
        <header class="header">
            <div class="container">
                <?php if (isset($component)) { $__componentOriginal5512557211bcf4a5508ae7a591e8395e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5512557211bcf4a5508ae7a591e8395e = $attributes; } ?>
<?php $component = A17\Twill\View\Components\Partials\Navigation\Title::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('twill.partials::navigation.title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\A17\Twill\View\Components\Partials\Navigation\Title::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5512557211bcf4a5508ae7a591e8395e)): ?>
<?php $attributes = $__attributesOriginal5512557211bcf4a5508ae7a591e8395e; ?>
<?php unset($__attributesOriginal5512557211bcf4a5508ae7a591e8395e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5512557211bcf4a5508ae7a591e8395e)): ?>
<?php $component = $__componentOriginal5512557211bcf4a5508ae7a591e8395e; ?>
<?php unset($__componentOriginal5512557211bcf4a5508ae7a591e8395e); ?>
<?php endif; ?>
               
                <?php if(config('twill.enabled.search', false) && !($isDashboard ?? false)): ?>
                    <div class="headerSearch" id="searchApp">
                        <a href="#" class="headerSearch__toggle" @click.prevent="toggleSearch">
                            <span v-svg symbol="search" v-show="!open"></span>
                            <span v-svg symbol="close_modal" v-show="open"></span>
                        </a>
                        <transition name="fade_search-overlay" @after-enter="afterAnimate">
                            <div class="headerSearch__wrapper" :style="positionStyle" v-show="open" v-cloak>
                                <div class="headerSearch__overlay" :style="positionStyle" @click="toggleSearch"></div>
                                <a17-search endpoint="<?php echo e(route(config('twill.dashboard.search_endpoint'))); ?>"
                                    :open="open" :opened="opened"></a17-search>
                            </div>
                        </transition>
                    </div>
                <?php endif; ?>
            </div>
        </header>
        <?php if (! empty(trim($__env->yieldContent('primaryNavigation')))): ?>
            <?php echo $__env->yieldContent('primaryNavigation'); ?>
        <?php else: ?>
            <?php if (isset($component)) { $__componentOriginald40350f27619129131ae05fbb6664a86 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald40350f27619129131ae05fbb6664a86 = $attributes; } ?>
<?php $component = A17\Twill\View\Components\Partials\Navigation\Breadcrumbs::resolve(['breadcrumb' => $breadcrumb ?? []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('twill.partials::navigation.breadcrumbs'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\A17\Twill\View\Components\Partials\Navigation\Breadcrumbs::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald40350f27619129131ae05fbb6664a86)): ?>
<?php $attributes = $__attributesOriginald40350f27619129131ae05fbb6664a86; ?>
<?php unset($__attributesOriginald40350f27619129131ae05fbb6664a86); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald40350f27619129131ae05fbb6664a86)): ?>
<?php $component = $__componentOriginald40350f27619129131ae05fbb6664a86; ?>
<?php unset($__componentOriginald40350f27619129131ae05fbb6664a86); ?>
<?php endif; ?>
        <?php endif; ?>
        <section class="main">
            <div class="app" id="app" v-cloak>
                <div class="twill-layout">
                    <div class="twill-sidebar-menu">
                        <?php if (isset($component)) { $__componentOriginale2b7e78abab8e57bd29a38483dd69f2e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale2b7e78abab8e57bd29a38483dd69f2e = $attributes; } ?>
<?php $component = A17\Twill\View\Components\Partials\Navigation\Primary::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('twill.partials::navigation.primary'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\A17\Twill\View\Components\Partials\Navigation\Primary::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale2b7e78abab8e57bd29a38483dd69f2e)): ?>
<?php $attributes = $__attributesOriginale2b7e78abab8e57bd29a38483dd69f2e; ?>
<?php unset($__attributesOriginale2b7e78abab8e57bd29a38483dd69f2e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale2b7e78abab8e57bd29a38483dd69f2e)): ?>
<?php $component = $__componentOriginale2b7e78abab8e57bd29a38483dd69f2e; ?>
<?php unset($__componentOriginale2b7e78abab8e57bd29a38483dd69f2e); ?>
<?php endif; ?>
                        <div class="header__user" id="headerUser" v-cloak>
                            <?php if (isset($component)) { $__componentOriginale80ec8065735a827ad3bfd0d7190aae9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale80ec8065735a827ad3bfd0d7190aae9 = $attributes; } ?>
<?php $component = A17\Twill\View\Components\Partials\Navigation\User::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('twill.partials::navigation.user'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\A17\Twill\View\Components\Partials\Navigation\User::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale80ec8065735a827ad3bfd0d7190aae9)): ?>
<?php $attributes = $__attributesOriginale80ec8065735a827ad3bfd0d7190aae9; ?>
<?php unset($__attributesOriginale80ec8065735a827ad3bfd0d7190aae9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale80ec8065735a827ad3bfd0d7190aae9)): ?>
<?php $component = $__componentOriginale80ec8065735a827ad3bfd0d7190aae9; ?>
<?php unset($__componentOriginale80ec8065735a827ad3bfd0d7190aae9); ?>
<?php endif; ?>
                        </div>
                    </div>
                    <div class="twill-content-wrapper">
                        <?php echo $__env->yieldContent('content'); ?>
                    </div>
                </div>
                <?php if(config('twill.enabled.media-library') || config('twill.enabled.file-library')): ?>
                    <a17-medialibrary ref="mediaLibrary"
                        :authorized="<?php echo e(json_encode(auth('twill_users')->user()->can('edit-media-library'))); ?>"
                        :extra-metadatas="<?php echo e(json_encode(array_values(config('twill.media_library.extra_metadatas_fields', [])))); ?>"
                        :translatable-metadatas="<?php echo e(json_encode(array_values(config('twill.media_library.translatable_metadatas_fields', [])))); ?>">
                    </a17-medialibrary>
                    <a17-dialog ref="deleteWarningMediaLibrary"
                        modal-title="<?php echo e(twillTrans('twill::lang.media-library.dialogs.delete.delete-media-title')); ?>"
                        confirm-label="<?php echo e(twillTrans('twill::lang.media-library.dialogs.delete.delete-media-confirm')); ?>">
                        <p class="modal--tiny-title">
                            <strong><?php echo e(twillTrans('twill::lang.media-library.dialogs.delete.delete-media-title')); ?></strong>
                        </p>
                        <p><?php echo twillTrans('twill::lang.media-library.dialogs.delete.delete-media-desc'); ?></p>
                    </a17-dialog>
                    <a17-dialog ref="replaceWarningMediaLibrary"
                        modal-title="<?php echo e(twillTrans('twill::lang.media-library.dialogs.replace.replace-media-title')); ?>"
                        confirm-label="<?php echo e(twillTrans('twill::lang.media-library.dialogs.replace.replace-media-confirm')); ?>">
                        <p class="modal--tiny-title">
                            <strong><?php echo e(twillTrans('twill::lang.media-library.dialogs.replace.replace-media-title')); ?></strong>
                        </p>
                        <p><?php echo twillTrans('twill::lang.media-library.dialogs.replace.replace-media-desc'); ?></p>
                    </a17-dialog>
                <?php endif; ?>
                <a17-notif variant="success"></a17-notif>
                <a17-notif variant="error"></a17-notif>
                <a17-notif variant="info" :auto-hide="false" :important="false"></a17-notif>
                <a17-notif variant="warning" :auto-hide="false" :important="false"></a17-notif>
            </div>
            <div class="appLoader">
                <span>
                    <span class="loader"><span></span></span>
                </span>
            </div>
            <?php echo $__env->make('twill::partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </section>
    </div>

    <?php if(config('twill.enabled.users-management')): ?>
        <form style="display: none" method="POST"
            action="<?php echo e(route(config('twill.admin_route_name_prefix') . 'logout')); ?>" data-logout-form>
            <?php echo csrf_field(); ?>
        </form>
    <?php endif; ?>

    <script>
        window['<?php echo e(config('twill.js_namespace')); ?>'] = {}
        window['<?php echo e(config('twill.js_namespace')); ?>'].debug = <?php echo e(config('twill.debug') ? 'true' : 'false'); ?>;
        window['<?php echo e(config('twill.js_namespace')); ?>'].version = '<?php echo e(config('twill.version')); ?>';
        window['<?php echo e(config('twill.js_namespace')); ?>'].twillLocalization = <?php echo json_encode($twillLocalization); ?>;
        window['<?php echo e(config('twill.js_namespace')); ?>'].STORE = {}
        window['<?php echo e(config('twill.js_namespace')); ?>'].STORE.form = {}
        window['<?php echo e(config('twill.js_namespace')); ?>'].STORE.config = {
            publishDateDisplayFormat: '<?php echo e(config('twill.publish_date_display_format')); ?>',
        }
        window['<?php echo e(config('twill.js_namespace')); ?>'].STORE.medias = {}
        window['<?php echo e(config('twill.js_namespace')); ?>'].STORE.medias.types = []
        window['<?php echo e(config('twill.js_namespace')); ?>'].STORE.medias.config = {
            useWysiwyg: <?php echo e(config('twill.media_library.media_caption_use_wysiwyg') ? 'true' : 'false'); ?>,
            wysiwygOptions: <?php echo json_encode(config('twill.media_library.media_caption_wysiwyg_options')); ?>

        }
        window['<?php echo e(config('twill.js_namespace')); ?>'].STORE.languages = <?php echo json_encode(getLanguagesForVueStore($form_fields ?? [], $translate ?? false)); ?>;

        <?php if(config('twill.enabled.media-library')): ?>
            window['<?php echo e(config('twill.js_namespace')); ?>'].STORE.medias.types.push({
                value: 'image',
                text: '<?php echo e(twillTrans('twill::lang.media-library.images')); ?>',
                total: <?php echo e(\A17\Twill\Models\Media::count()); ?>,
                endpoint: '<?php echo e(route(config('twill.admin_route_name_prefix') . 'media-library.medias.index')); ?>',
                tagsEndpoint: '<?php echo e(route(config('twill.admin_route_name_prefix') . 'media-library.medias.tags')); ?>',
                uploaderConfig: <?php echo json_encode($mediasUploaderConfig); ?>

            })
            window['<?php echo e(config('twill.js_namespace')); ?>'].STORE.medias.showFileName = !!
                '<?php echo e(config('twill.media_library.show_file_name')); ?>'
        <?php endif; ?>

        <?php if(config('twill.enabled.file-library')): ?>
            window['<?php echo e(config('twill.js_namespace')); ?>'].STORE.medias.types.push({
                value: 'file',
                text: '<?php echo e(twillTrans('twill::lang.media-library.files')); ?>',
                total: <?php echo e(\A17\Twill\Models\File::count()); ?>,
                endpoint: '<?php echo e(route(config('twill.admin_route_name_prefix') . 'file-library.files.index')); ?>',
                tagsEndpoint: '<?php echo e(route(config('twill.admin_route_name_prefix') . 'file-library.files.tags')); ?>',
                uploaderConfig: <?php echo json_encode($filesUploaderConfig); ?>

            })
        <?php endif; ?>


        <?php echo $__env->yieldContent('initialStore'); ?>

        window.STORE = {}
        window.STORE.form = {}
        window.STORE.publication = {}
        window.STORE.medias = {}
        window.STORE.medias.types = []
        window.STORE.medias.selected = {}
        window.STORE.browsers = {}
        window.STORE.browsers.selected = {}

        <?php echo $__env->yieldPushContent('vuexStore'); ?>
    </script>
    <script src="<?php echo e(twillAsset('chunk-vendors.js')); ?>"></script>
    <script src="<?php echo e(twillAsset('chunk-common.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('extra_js'); ?>
</body>

</html>
<?php /**PATH /var/www/medera-cms/resources/views/vendor/twill/layouts/main.blade.php ENDPATH**/ ?>