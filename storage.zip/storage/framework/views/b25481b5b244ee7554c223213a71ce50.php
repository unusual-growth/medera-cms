<script>
    let validationMsg = <?php echo $validation ?? 'null'; ?>;
</script>


<?php if(key_exists('inputs', $formData)): ?>
    <form class="form-group row <?php echo e(isset($formData['class']) ? $formData['class'] : ''); ?>" id="<?php echo e(isset($formData['id']) ? $formData['id'] : ''); ?>" action="<?php echo e(isset($formData['action']) ? $formData['action'] : ''); ?>" method="<?php echo e(isset($formData['method']) ? $formData['method'] : 'POST'); ?>">
        <?php if(isset($formData['title'])): ?>
            <?php if(isset($formData['title']['type'])): ?>
                <<?php echo e($formData['title']['type']); ?>

                class="<?php echo e(isset($formData['title']['class']) ? $formData['title']['class'] : ''); ?>">
                <?php echo e(__($formData['title']['content'])); ?>

                </<?php echo e($formData['title']['type']); ?>>

            <?php else: ?>
                <h2 class="<?php echo e(isset($formData['title']['class']) ? $formData['title']['class'] : ''); ?>">
                    <?php echo e(__($formData['title']['content'])); ?>

                </h2>
            <?php endif; ?>
        <?php endif; ?>
        <?php $__currentLoopData = $formData['inputs']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
                <?php echo $__env->make('unusual_form::inputs._' . $arr['type'], array_diff_key($arr, array_flip(["type"])), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </form>

<?php elseif(key_exists('steps',$formData)): ?>
        <form class="form-group row <?php echo e(isset($formData['class']) ? $formData['class'] : ''); ?>" id="<?php echo e(isset($formData['id']) ? $formData['id'] : ''); ?>">
            <?php $__currentLoopData = $formData['steps']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $forms): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="form-step step-<?php echo e($loop->index); ?> <?php echo e($loop->index === 0 ? 'active' : ''); ?>">
                <?php if(isset($forms['title'])): ?>
                    <?php if(isset($forms['title']['type'])): ?>
                        <<?php echo e($forms['title']['type']); ?>

                        class="<?php echo e(isset($forms['title']['class']) ? $forms['title']['class'] : ''); ?>">
                        <?php echo e($forms['title']['content']); ?>

                        </<?php echo e($forms['title']['type']); ?>>

                    <?php else: ?>
                        <h2 class="<?php echo e(isset($title['class']) ? $forms['title']['class'] : ''); ?>">
                            <?php echo e($forms['title']['content']); ?>

                        </h2>

                    <?php endif; ?>
                <?php endif; ?>
                    
                    <?php $__currentLoopData = $forms['inputs']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo $__env->make('unusual_form::inputs._' . $arr['type'], array_diff_key($arr, array_flip(["type"])), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </form>

<?php else: ?>

    <?php $__currentLoopData = $formData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $forms): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <form class="form-group row form-step step-<?php echo e($loop->index); ?>" id="<?php echo e(isset($formData['id']) ? $formData['id'] : ''); ?>">
            <?php if(isset($forms['title'])): ?>
            <?php if(isset($forms['title']['type'])): ?>
                <<?php echo e($forms['title']['type']); ?>

                class="<?php echo e(isset($forms['title']['class']) ? $forms['title']['class'] : ''); ?>">
                <?php echo e($forms['title']['content']); ?>

                </<?php echo e($forms['title']['type']); ?>>

            <?php else: ?>
                <h2 class="<?php echo e(isset($title['class']) ? $forms['title']['class'] : ''); ?>">
                    <?php echo e($forms['title']['content']); ?>

                </h2>
            <?php endif; ?>
            <?php endif; ?>
            <?php $__currentLoopData = $forms['inputs']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('unusual_form::inputs._' . $arr['type'], array_diff_key($arr, array_flip(["type"])), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </form>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php endif; ?>

<?php /**PATH /var/www/medera-cms/packages/unusualify/laravel-form/src/Resources/views/layouts/_form.blade.php ENDPATH**/ ?>