<?php echo $__env->make('twill-image::picture', [
    'fallback' => $mainSrc,
    'attributes' => 'data-twill-image-main',
    'sources' => $mainSources ?? [],
    'style' => $mainStyle ?? null,
    'class' => $mainClasses ?? null,
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /var/www/medera-cms/vendor/area17/twill-image/src/../resources/views/main-image.blade.php ENDPATH**/ ?>