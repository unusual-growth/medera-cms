<?php if($class === 'mobile'): ?>
    <a href="<?php echo e($href); ?>" <?php $__currentLoopData = $attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($attribute); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> class="<?php if($is_active): ?> s--on <?php endif; ?>" <?php if($target_blank): ?> target="_blank" <?php endif; ?>>
        <?php echo e($title); ?>

    </a>
<?php else: ?>
    <li class="<?php echo e($class ?? ''); ?> <?php if($is_active): ?> s--on <?php endif; ?>">
        <a href="<?php echo e($href); ?>" <?php $__currentLoopData = $attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($attribute); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php if($target_blank): ?> target="_blank" <?php endif; ?>>
            <?php echo e($title); ?>

        </a>
    </li>
<?php endif; ?>
<?php /**PATH /var/www/medera-cms/resources/views/vendor/twill/partials/navigation/navigation_link.blade.php ENDPATH**/ ?>