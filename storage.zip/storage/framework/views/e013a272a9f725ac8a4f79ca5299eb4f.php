<?php if(isset($currentUser) && config('twill.enabled.users-management')): ?>
    <?php
        $user_management_route = config('twill.admin_route_name_prefix') . 'users.index';
        if ($currentUser->can('edit-users')) {
            $user_management_route = config('twill.admin_route_name_prefix') . 'users.index';
        } elseif ($currentUser->can('edit-user-roles')) {
            $user_management_route = config('twill.admin_route_name_prefix') . 'roles.index';
        } elseif ($currentUser->can('edit-user-groups')) {
            $user_management_route = config('twill.admin_route_name_prefix') . 'groups.index';
        }
    ?>

    <ul>
        <li class="header__item <?php echo e(request()->routeIs(config('twill.admin_route_name_prefix') . 'users.edit') ? 's--on' : ''); ?>">
            <a href="<?php echo e(route(config('twill.admin_route_name_prefix') . 'users.edit', $currentUser->id)); ?>"
                @click.prevent="$refs.userDropdown.toggle()">
                <?php echo e($currentUser->role === 'SUPERADMIN' ? twillTrans('twill::lang.nav.admin') : $currentUser->name); ?>

            </a>
        </li>
        <?php if($currentUser->can('access-user-management')): ?>
            <li class="header__item header__subitem <?php echo e(request()->routeIs($user_management_route) ? 's--on' : ''); ?>">
                <a href="<?php echo e(route($user_management_route)); ?>"><?php echo e(twillTrans('twill::lang.nav.cms-users')); ?></a>
            </li>
        <?php endif; ?>
        <li class="header__item header__subitem <?php echo e(request()->routeIs(config('twill.admin_route_name_prefix') . 'users.edit') ? 's--on' : ''); ?>">
            <a
                href="<?php echo e(route(config('twill.admin_route_name_prefix') . 'users.edit', $currentUser->id)); ?>"><?php echo e(twillTrans('twill::lang.nav.profile')); ?></a>
        </li>
        <li class="header__item header__subitem">
            <a href="#" data-logout-btn><?php echo e(twillTrans('twill::lang.nav.logout')); ?></a>
        </li>
    </ul>
<?php endif; ?>
<?php /**PATH /var/www/medera-cms/resources/views/vendor/twill/partials/navigation/_user.blade.php ENDPATH**/ ?>