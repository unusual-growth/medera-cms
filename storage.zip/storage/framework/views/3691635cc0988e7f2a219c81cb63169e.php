<a17-inputframe>
    <details>
        <summary>
            <span class="f--underlined"><?php echo e($label); ?></span>
            <?php if(isset($description)): ?>
                - <span class="f--small"><?php echo e($note); ?></span>
            <?php endif; ?>
        </summary>
        <?php if(isset($fields)): ?>
            <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $field->render(); ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </details>
</a17-inputframe>
<?php /**PATH /var/www/medera-cms/resources/views/partials/form/utils/_collapsible-container.blade.php ENDPATH**/ ?>