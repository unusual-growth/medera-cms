<a17-fieldset title="<?php echo e($title); ?>" <?php if(isset($id)): ?> id="<?php echo e($id); ?>" <?php endif; ?> <?php if(isset($open)): ?> :open="<?php echo e($open ? 'true' : 'false'); ?>" <?php endif; ?>>
    <?php echo e($slot); ?>

</a17-fieldset>
<?php /**PATH /var/www/medera-cms/resources/views/vendor/twill/partials/form/utils/_fieldset.blade.php ENDPATH**/ ?>