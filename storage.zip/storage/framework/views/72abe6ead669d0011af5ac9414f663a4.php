<?php if($translated): ?>
    <a17-locale
        type="a17-textfield"
        :attributes="{
            label: '<?php echo e($label); ?>',
            <?php echo $formFieldName(true); ?>,
            type: '<?php echo e($type); ?>',
            <?php if($required): ?> required: true, <?php endif; ?>
            <?php if($note): ?> note: '<?php echo e($note); ?>', <?php endif; ?>
            <?php if($placeholder): ?> placeholder: '<?php echo e(addslashes($placeholder)); ?>', <?php endif; ?>
            <?php if($direction): ?> direction: '<?php echo e($direction); ?>', <?php endif; ?>
            <?php if($maxlength): ?> maxlength: <?php echo e($maxlength); ?>, <?php endif; ?>
            <?php if($disabled): ?> disabled: true, <?php endif; ?>
            <?php if($readOnly): ?> readonly: true, <?php endif; ?>
            <?php if($rows): ?> rows: <?php echo e($rows); ?>, <?php endif; ?>
            <?php if($prefix): ?> prefix: '<?php echo e($prefix); ?>', <?php endif; ?>
            <?php if($mask): ?> mask: '<?php echo e($mask); ?>', <?php endif; ?>
            <?php if($inModal): ?> inModal: true, <?php endif; ?>
            <?php if(isset($min)): ?> min: <?php echo e($min); ?>, <?php endif; ?>
            <?php if(isset($max)): ?> max: <?php echo e($max); ?>, <?php endif; ?>
            <?php if($step): ?> step: <?php echo e($step); ?>, <?php endif; ?>
            <?php if($default): ?>
                initialValue: '<?php echo e($default); ?>',
                hasDefaultStore: true,
            <?php endif; ?>
            inStore: 'value'
        }"
        <?php if($ref): ?> ref="<?php echo e($ref); ?>" <?php endif; ?>
        <?php if($onChange): ?> v-on:change="<?php echo e($onChange); ?><?php echo e($onChangeFullAttribute); ?>" <?php endif; ?>
    ></a17-locale>
<?php else: ?>
    <a17-textfield
        label="<?php echo e($label); ?>"
        <?php echo $formFieldName(); ?>

        type="<?php echo e($type); ?>"
        <?php if($required): ?> :required="true" <?php endif; ?>
        <?php if($note): ?> note="<?php echo e($note); ?>" <?php endif; ?>
        <?php if($placeholder): ?> placeholder="<?php echo e($placeholder); ?>" <?php endif; ?>
        <?php if($direction): ?> direction="<?php echo e($direction); ?>" <?php endif; ?>
        <?php if($maxlength): ?> :maxlength="<?php echo e($maxlength); ?>" <?php endif; ?>
        <?php if($disabled): ?> disabled <?php endif; ?>
        <?php if($readOnly): ?> readonly <?php endif; ?>
        <?php if($rows): ?> :rows="<?php echo e($rows); ?>" <?php endif; ?>
        <?php if($ref): ?> ref="<?php echo e($ref); ?>" <?php endif; ?>
        <?php if($onChange): ?> v-on:change="<?php echo e($onChange); ?><?php echo e($onChangeFullAttribute); ?>" <?php endif; ?>
        <?php if($prefix): ?> prefix="<?php echo e($prefix); ?>" <?php endif; ?>
        <?php if($mask): ?> mask="<?php echo e($mask); ?>" <?php endif; ?>
        <?php if($inModal): ?> :in-modal="true" <?php endif; ?>
        <?php if(isset($min)): ?> :min="<?php echo e($min); ?>" <?php endif; ?>
        <?php if(isset($max)): ?> :max="<?php echo e($max); ?>" <?php endif; ?>
        <?php if($step): ?> step="<?php echo e($step); ?>" <?php endif; ?>
        <?php if($default): ?>
            :initial-value="'<?php echo e($default); ?>'"
            :has-default-store="true"
        <?php endif; ?>
        in-store="value"
    ></a17-textfield>
<?php endif; ?>

<?php if (! ($renderForBlocks || $renderForModal)): ?>
<?php $__env->startPush('vuexStore'); ?>
    <?php echo $__env->make('twill::partials.form.utils._translatable_input_store', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>
<?php endif; ?>
<?php /**PATH /var/www/medera-cms/resources/views/vendor/twill/partials/form/_input.blade.php ENDPATH**/ ?>