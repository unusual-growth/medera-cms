<?php
    $isEqual = $isEqual ?? true;
    $inModal = $fieldsInModal ?? false;
    $isBrowser = $isBrowser ?? false;
    $matchEmptyBrowser = $matchEmptyBrowser ?? false;
    $arrayContains = $arrayContains ?? true;
    $keepAlive = $keepAlive ?? false;

    if (! $isBrowser) {
        // Field values misc updates
        $fieldType = gettype($fieldValues);
        if ($fieldType === 'boolean') $fieldValues = $fieldValues ? "true" :  "false";
        else if ($fieldType === 'array') $fieldValues = json_encode($fieldValues);
    }
?>
<a17-connectorfield
    <?php if($isEqual): ?> :is-value-equal="true" <?php else: ?> :is-value-equal="false" <?php endif; ?>
    <?php if($inModal): ?> :in-modal="true" <?php endif; ?>
    <?php if($keepAlive): ?> :keep-alive="true" <?php endif; ?>

    <?php if($arrayContains): ?> :array-contains="true" <?php else: ?> :array-contains="false" <?php endif; ?>

    <?php if($isBrowser): ?> :is-browser="true" <?php endif; ?>
    <?php if($matchEmptyBrowser): ?> :match-empty-browser="true" <?php endif; ?>

    <?php if($renderForBlocks): ?> :field-name="fieldName('<?php echo e($fieldName); ?>')"
    <?php else: ?> field-name="<?php echo e($fieldName); ?>"
    <?php endif; ?>

    <?php if (! ($isBrowser)): ?>
        <?php if($fieldType === 'array'): ?> :required-field-values='<?php echo $fieldValues; ?>'
        <?php elseif($fieldType === 'string'): ?> :required-field-values="'<?php echo e($fieldValues); ?>'"
        <?php else: ?> :required-field-values="<?php echo e($fieldValues); ?>"
        <?php endif; ?>
    <?php endif; ?>
>
    <?php echo $slot; ?>

</a17-connectorfield>
<?php /**PATH /var/www/medera-cms/resources/views/vendor/twill/partials/form/utils/_connected_fields.blade.php ENDPATH**/ ?>