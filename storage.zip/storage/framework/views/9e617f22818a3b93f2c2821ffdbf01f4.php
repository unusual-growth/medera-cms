<?php
    $img = $block->imagesAsArrays('image')[0];
?>
<section class="accordion-section">
    <div class="container xlarge">
        <div class="row">
            <h2> <?php echo e($translatedInput('title')); ?> </h2>
        </div>
        <div class="row gap-30">
            <div class="col-md-6">
                    

                    <img
                        
                        src="<?php echo e($img["src"]); ?>" alt="<?php echo e($img["alt"]); ?>" />
            </div>
            <div class="col-md-6">
                <?php $__currentLoopData = $repeater('accordion-items'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $_block = $item->renderData->block;
                        $_img = $_block->imagesAsArrays('icon')[0];
                    ?>
                    
                    <div class="accordion-item <?php echo e($loop->first ? 'active' : ''); ?>">
                        <div class="question" data-accordion="<?php echo e($key); ?>">
                            <div class="question-content">
                                <img  width="34" height="34" src="<?php echo e($_img['src']); ?>" alt="<?php echo e($_img['alt']); ?>" />
                                <h4 itemprop="name"><?php echo e($_block->translatedInput('title')); ?></h4>
                            </div>
                            <img src="/dummy-img/arrow.svg" class="arrow"></img>
                        </div>
                        <div class="accordion-answer">
                            <div class="answer-content" itemprop="text">
                                <?php echo $_block->translatedInput('content'); ?>

                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</section>
<?php /**PATH /var/www/medera-cms/resources/views/components/twill/blocks/accordionwithsingleimage.blade.php ENDPATH**/ ?>