<?php $__env->startSection('input'); ?>
<?php
    $checked = (isset($model) ? $model->getFormInputValue($input_name) : '') == '1' ? 'checked' : '';
?>
<div class="custom-control custom-switch">
    
    <input
        type="checkbox"
        class="custom-control-input <?php echo e($class ? $class :''); ?>"
        name="<?php echo e($input_name); ?>"
        id="<?php echo e($input_name); ?>_checkbox"
        value="1"
        <?php echo e($checked); ?>

        <?php echo e($props ?? ''); ?>

        >
    <?php if(isset($label)): ?>
        <label class="custom-control-label" for="<?php echo e($input_name); ?>_checkbox"> <span><?php echo __($label); ?></span></label>
    <?php endif; ?>
    <span class="help-block" for="<?php echo e($input_name); ?>"></span>
</div>

<?php $__env->stopSection(true); ?>

<?php echo $__env->make('unusual_form::layouts._input-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/medera-cms/vendor/unusualify/laravel-form/src/Resources/views/inputs/_checkbox.blade.php ENDPATH**/ ?>