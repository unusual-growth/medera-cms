<?php
    $has_image = $block->hasImage('col_image');
    if ($has_image) {
        $image = TwillImage::make($block, 'col_image')->crop('default')->width(592)->toArray();
    }

    $image_right = $input('image_right');
    $color_mode = $input('color_mode');
    $reverse_order_mobile = $input('reverse_order_mobile');
    // $color_scheme = $input('color_scheme');
?>

<section class="journey-section">
  <div class="container xlarge journey-container">
    <div class="row <?php echo e($reverse_order_mobile ? 'mob-rev' : ''); ?> <?php echo e($image_right ? 'reverse' : ''); ?>">
      <div class="journey-image col-sm-5 d-flex">
        <?php if($has_image): ?>
            <?php echo TwillImage::render($image, []); ?>

        <?php else: ?>
            <div style="width: 100%; height: 300px; color: white; display: flex; justify-content: center; align-items: center;">
                Please add an image.
            </div>
        <?php endif; ?>
      </div>
      <div class="journey-content height-500 <?php echo e($color_mode == 'dark' ? 'dusky-blush-gradient' : 'bg-light'); ?> col-sm-7">
          <div>
            <?php echo $translatedInput('text'); ?>


          </div>
      </div>
    </div>
  </div>
</section>
<?php /**PATH /var/www/medera-cms/resources/views/components/twill/blocks/doublecolumnframedcontent.blade.php ENDPATH**/ ?>