<?php if(isset($arr['col']) && !$arr['hasParent']): ?>

<div class="  col
              col-<?php echo e(isset($arr['col']) ? $arr['col']['default'] : '12'); ?> 
              col-xs-<?php echo e(isset($arr['col']) ? $arr['col']['xs'] : '12'); ?> 
              col-sm-<?php echo e(isset($arr['col']) ? $arr['col']['sm'] : '12'); ?> 
              col-md-<?php echo e(isset($arr['col']) ? $arr['col']['md'] : '12'); ?> 
              col-lg-<?php echo e(isset($arr['col']) ? $arr['col']['lg'] : '12'); ?> 
              col-xl-<?php echo e(isset($arr['col']) ? $arr['col']['xl'] : '12'); ?>

              col-xxl-<?php echo e(isset($arr['col']) ? $arr['col']['xxl'] : '12'); ?>

              <?php echo e(isset($arr['align-center']) ? 'align-items-center' : ''); ?>

              <?php echo e(isset($arr['justify-center']) ? 'justify-content-center' : ''); ?>


              ">
              
    <?php echo $__env->yieldContent('input'); ?>
  </div>

<?php else: ?>

  
      <?php echo $__env->yieldContent('input'); ?>


<?php endif; ?>


<?php /**PATH /var/www/medera-cms/packages/unusualify/laravel-form/src/Resources/views/layouts/_input-template.blade.php ENDPATH**/ ?>