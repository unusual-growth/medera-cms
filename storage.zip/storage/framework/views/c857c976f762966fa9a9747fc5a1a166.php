<section class="">
    <div class="container xlarge">
        <div>
            <h2 class="font-weight-700">
                <?php echo e($translatedInput('heading')); ?>

            </h2>
            <h4 class="color-secondary">
                <?php echo e($translatedInput('text')); ?>

            </h4>
        </div>
        <div class="faq-listing">
            <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="cell">
                    <div class="item" data-id="<?php echo e($loop->index); ?>">
                        <h4>
                            <?php echo e($item->title); ?>

                        </h4>
                        <div>
                            <div>
                                <p>
                                    <?php echo e($item->answer); ?>

                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php if($input('show_link')): ?>
            <a class="primary-cta" href="/faq">Visit FAQ Page</a>
        <?php endif; ?>
    </div>
</section>
<?php /**PATH /var/www/medera-cms/resources/views/components/twill/blocks/faqlistings.blade.php ENDPATH**/ ?>