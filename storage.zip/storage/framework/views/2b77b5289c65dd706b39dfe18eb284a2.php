<?php if (isset($component)) { $__componentOriginal6dbb8a3d0dca16b32bd023fdc4ac8605 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6dbb8a3d0dca16b32bd023fdc4ac8605 = $attributes; } ?>
<?php $component = A17\Twill\View\Components\Fields\Input::resolve(['name' => $name,'label' => $label,'translated' => $translated,'note' => $note] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('twill::input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\A17\Twill\View\Components\Fields\Input::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6dbb8a3d0dca16b32bd023fdc4ac8605)): ?>
<?php $attributes = $__attributesOriginal6dbb8a3d0dca16b32bd023fdc4ac8605; ?>
<?php unset($__attributesOriginal6dbb8a3d0dca16b32bd023fdc4ac8605); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6dbb8a3d0dca16b32bd023fdc4ac8605)): ?>
<?php $component = $__componentOriginal6dbb8a3d0dca16b32bd023fdc4ac8605; ?>
<?php unset($__componentOriginal6dbb8a3d0dca16b32bd023fdc4ac8605); ?>
<?php endif; ?><?php /**PATH /var/www/medera-cms/storage/framework/views/5969e39bdcdc197313299bd8e7092b9e.blade.php ENDPATH**/ ?>