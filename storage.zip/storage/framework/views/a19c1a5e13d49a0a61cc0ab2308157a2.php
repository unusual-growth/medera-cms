<?php if (isset($component)) { $__componentOriginalfef895a92db6ef83dd9781fae312cf3a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfef895a92db6ef83dd9781fae312cf3a = $attributes; } ?>
<?php $component = A17\Twill\View\Components\Fields\Checkbox::resolve(['name' => $name,'label' => $label] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('twill::checkbox'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\A17\Twill\View\Components\Fields\Checkbox::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfef895a92db6ef83dd9781fae312cf3a)): ?>
<?php $attributes = $__attributesOriginalfef895a92db6ef83dd9781fae312cf3a; ?>
<?php unset($__attributesOriginalfef895a92db6ef83dd9781fae312cf3a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfef895a92db6ef83dd9781fae312cf3a)): ?>
<?php $component = $__componentOriginalfef895a92db6ef83dd9781fae312cf3a; ?>
<?php unset($__componentOriginalfef895a92db6ef83dd9781fae312cf3a); ?>
<?php endif; ?><?php /**PATH /var/www/medera-cms/storage/framework/views/cd37f6875a6c09e1d59f0a319096d18c.blade.php ENDPATH**/ ?>