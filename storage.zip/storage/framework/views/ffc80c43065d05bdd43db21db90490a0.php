<?php if (! ($withoutSeparator)): ?>
    <hr />
<?php endif; ?>

<a17-blocks title="<?php echo e($label); ?>"
    <?php if($renderForBlocks): ?> :editor-name="nestedEditorName('<?php echo e($name); ?>')" <?php else: ?> editor-name="<?php echo e($name); ?>" <?php endif; ?>
    trigger="<?php echo e($trigger); ?>" :is-settings="<?php echo e((bool) $isSettings ? 'true' : 'false'); ?>">
</a17-blocks>

<?php $__env->startPush('vuexStore'); ?>
    window['<?php echo e(config('twill.js_namespace')); ?>'].STORE.form.availableBlocks['<?php echo e($name); ?>'] =
    <?php echo json_encode(array_values($allowedBlocks)); ?>

    window['<?php echo e(config('twill.js_namespace')); ?>'].STORE.form.editorNames.push(<?php echo json_encode($editorName); ?>)
<?php $__env->stopPush(); ?>

<?php if (! $__env->hasRenderedOnce('form:block_editor')): $__env->markAsRenderedOnce('form:block_editor');
$__env->startPush('vuexStore'); ?>
    <?php echo $__env->make('twill::partials.form.utils._block_editor_store', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); endif; ?>
<?php /**PATH /var/www/medera-cms/resources/views/vendor/twill/partials/form/_block_editor.blade.php ENDPATH**/ ?>