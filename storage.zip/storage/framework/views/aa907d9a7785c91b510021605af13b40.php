<section class="pills-banner">
    <picture>
        <source srcset="<?php echo e($block->image('background-image', 'default')); ?>" media="(min-width: 768px)">
        <img src="<?php echo e($block->image('background-image-mobile')); ?>" alt="">
    </picture>
    <div class="container xlarge">
        <div class="row">
            <?php $__currentLoopData = $repeater('texts'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $repeaterItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $_renderData = $repeaterItem->renderData;
                    $icon_block = $_renderData->block;
                    $title = $icon_block->translatedInput('title');
                ?>
                <div>
                    <p> <?php echo e($title); ?></p>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
</section>
<?php /**PATH /var/www/medera-cms/resources/views/components/twill/blocks/columncardswithfullbackground.blade.php ENDPATH**/ ?>