<?php
    $currentSlug = request()->segment(2);
    if (isset($type) && $type == 'mobile') {
        // dd($links);
    }
?>
<ul>
    <?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $page = $link->getRelated('page')->first();
            if ($page) {
                $linkSlug = $page->slug;
                $isActive = isset($item) && $page instanceof $item && $page->id == $item->id ? 'active' : '';
            } else {
            }
        ?>
        <?php
            if ($type == 'mobile' && isset($link->children) && count($link->children) > 0) {
            }
        ?>

        <?php if(isset($link->children) && count($link->children) > 0): ?>
            <?php if(isset($type) && $type == 'desktop'): ?>
                <li>
                    <div class="dropdown">
                        <?php if($page): ?>
                            <a
                                href="<?php echo e($page->getLocalizedUriWithRoute(LaravelLocalization::getCurrentLocale())); ?>"><?php echo e($link->title); ?></a>
                        <?php else: ?>
                            <span><?php echo e($link->title); ?></span>
                        <?php endif; ?>
                        <div class="dropdown-content">
                            <div>
                                <?php $__currentLoopData = $link->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $subitemSlug = $subitem->getRelated('page')->first()->slug;
                                        $isActive =
                                            isset($item) && $subitem instanceof $item && $subitem->id == $item->id
                                                ? 'active'
                                                : '';
                                    ?>
                                    <a href="<?php echo e($subitem->getRelated('page')->first()->getLocalizedUriWithRoute(LaravelLocalization::getCurrentLocale())); ?>"
                                        class="<?php echo e($isActive); ?>"><?php echo e($subitem->title); ?></a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </li>
            <?php else: ?>
                <li class="hasSub">
                    <div class="flex-center justify-space-between width-95">
                        <span><?php echo e($link->title); ?></span>
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                            xmlns="http://www.w3.org/2000/svg">
                            <path d="m17.613 15-5.87-6-5.872 6" stroke="#427277" stroke-width="2" stroke-linecap="round"
                                stroke-linejoin="round" />
                        </svg>
                    </div>
                    <ul class="submenu">
                        <?php $__currentLoopData = $link->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $subitemSlug = $subitem->getRelated('page')->first()->slug;
                                $isActive = $currentSlug === $subitemSlug ? 'active' : '';
                            ?>
                            <li>
                                <a href="<?php echo e($subitem->getRelated('page')->first()->getLocalizedUriWithRoute(LaravelLocalization::getCurrentLocale())); ?>"
                                    class="<?php echo e($isActive); ?>"><?php echo e($subitem->title); ?></a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </li>
            <?php endif; ?>
        <?php else: ?>
            <li>
                <?php if($page): ?>
                    <a href="<?php echo e($page->getLocalizedUriWithRoute(LaravelLocalization::getCurrentLocale())); ?>"
                        class="<?php echo e($isActive); ?>"><?php echo e($link->title); ?></a>
                <?php else: ?>
                    <span><?php echo e($link->title); ?></span>
                <?php endif; ?>
            </li>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    

        
    
</ul>
<?php /**PATH /var/www/medera-cms/resources/views/components/menu.blade.php ENDPATH**/ ?>