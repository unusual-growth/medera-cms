<?php if($fields->isNotEmpty()): ?>
  <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($fields->forBlocks()): ?>
        <?php
            $field->renderForBlocks = true;
        ?>
    <?php endif; ?>
    <?php echo $field->render(); ?>

  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH /var/www/medera-cms/resources/views/vendor/twill/partials/form/renderer/block_form.blade.php ENDPATH**/ ?>