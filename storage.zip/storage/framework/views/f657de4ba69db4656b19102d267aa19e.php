    
    <?php
        $learnMoreCards = [
            [
                'title' => 'Where do you get butyrate from?',
                'description' =>
                    'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore etconsectetur seddo eiusmod tempo.',
                'link' => 'learn more',
            ],
            [
                'title' => 'Are your butyrate products halal?',
                'description' =>
                    'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore etconsectetur seddo eiusmod tempo.',
                'link' => 'learn more',
            ],
            [
                'title' => 'Do you have a vegan certificate?',
                'description' =>
                    'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore etconsectetur seddo eiusmod tempo.',
                'link' => 'learn more',
            ],
        ];
    ?>
    <section class="learnmore-cards">
        <div class="container xlarge">
            <h2> Any questions? We are here to help!</h2>
            <div class="card-container">
                
                <?php $__currentLoopData = $block->getRelated('faqs'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card">
                        <h3> <?php echo e($item->title); ?> </h3>
                        <p> <?php echo e($item->excerpt); ?> </p>
                        <a class="primary-cta" href="<?php echo e($translatedInput('link')); ?>" target="_blank"><?php echo e(__('util.read-more')); ?></a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
<?php /**PATH /var/www/medera-cms/resources/views/components/twill/blocks/featuredfaq.blade.php ENDPATH**/ ?>