<?php
    $color_scheme = $input('color_scheme');
?>
<section class="gut-health-section <?php echo e($color_scheme == 'peach' ? 'preset-color-peach' : ''); ?>">
    <div class="container xlarge">
        <div class="row justify-space-between">
            <div class="col-md-5 text-content">
                <?php echo $translatedInput('section_text'); ?>

            </div>

            <div class=" col-md-6 product-content">
                <?php if($block->hasImage('col_image')): ?>
                    <img src="<?php echo e($block->image('col_image')); ?>" alt="Butyrate Supplement Bottle" class="product-image">
                <?php endif; ?>
                <div class="capsule-info preset-color-primary">
                    <?php echo $translatedInput('right_text'); ?>

                </div>
                <div class="info-box preset-color-primary">
                    <?php echo $translatedInput('left_text'); ?>

                </div>
            </div>
        </div>
    </div>
</section>
<?php /**PATH /var/www/medera-cms/resources/views/components/twill/blocks/fourinone.blade.php ENDPATH**/ ?>