<?php
    $colClassAttr = (isset($middle) || isset($middleFields)) ? 'col--third col--third-wrap' : 'col--double col--double-wrap';
?>
<div class="wrapper">
    <div class="<?php echo e($colClassAttr); ?>">
      <?php if(isset($leftFields)): ?>
        <?php $__currentLoopData = $leftFields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $field->render(); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
      <?php echo e($left); ?>

    </div>
    <?php if(isset($middle) || isset($middleFields)): ?>
    <div class="<?php echo e($colClassAttr); ?>">
      <?php if(isset($middleFields)): ?>
        <?php $__currentLoopData = $middleFields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $field->render(); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
      <?php echo e($middle); ?>

    </div>
    <?php endif; ?>
    <div class="<?php echo e($colClassAttr); ?>">
      <?php if(isset($rightFields)): ?>
        <?php $__currentLoopData = $rightFields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php echo $field->render(); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
      <?php echo e($right); ?>

    </div>
</div>
<?php /**PATH /var/www/medera-cms/resources/views/vendor/twill/partials/form/utils/_columns.blade.php ENDPATH**/ ?>