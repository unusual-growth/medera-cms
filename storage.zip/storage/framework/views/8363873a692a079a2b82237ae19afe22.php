<img
    decoding="async"
    src="<?php echo e($src); ?>"
    <?php if(isset($loading)): ?> loading="<?php echo e($loading); ?>" <?php endif; ?>
    <?php if(isset($srcSet)): ?> srcset="<?php echo e($srcSet); ?>" <?php endif; ?>
    <?php if(isset($srcSet) && isset($sizes)): ?> sizes="<?php echo e($sizes); ?>" <?php endif; ?>
    <?php if(isset($alt)): ?> alt="<?php echo e($alt); ?>" <?php endif; ?>
    <?php if(isset($style)): ?> style="<?php echo e($style); ?>" <?php endif; ?>
    <?php if(isset($class)): ?> class="<?php echo e($class); ?>" <?php endif; ?>
    <?php if(isset($attributes)): ?> <?php echo $attributes; ?> <?php endif; ?>
/>
<?php /**PATH /var/www/medera-cms/vendor/area17/twill-image/src/../resources/views/image.blade.php ENDPATH**/ ?>