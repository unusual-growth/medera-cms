<?php
    $blocks = \A17\Twill\Facades\TwillBlocks::getBlockCollection()
        ->collect()
        ->reject(function ($block) {
            return $block->compiled ?? false;
        });
?>

<?php $__currentLoopData = $blocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $block): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <script type="text/x-template" id="<?php echo e($block->component); ?>">
        <div class="block__body">
            <?php echo $block->renderForm(); ?>

        </div>
    </script>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php
    $names = $blocks
        ->pluck('component')
        ->values();
?>

<script>
    window['<?php echo e(config('twill.js_namespace')); ?>'].TWILL_BLOCKS_COMPONENTS = <?php echo $names->toJson(); ?>

    window['<?php echo e(config('twill.js_namespace')); ?>'].STORE.form.availableRepeaters = <?php echo \A17\Twill\Facades\TwillBlocks::getAvailableRepeaters() ?? '{}'; ?>


</script>

<?php /**PATH /var/www/medera-cms/resources/views/vendor/twill/partials/form/utils/_blocks_templates.blade.php ENDPATH**/ ?>