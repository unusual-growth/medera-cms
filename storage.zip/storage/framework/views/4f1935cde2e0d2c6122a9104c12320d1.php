<?php if (isset($component)) { $__componentOriginal74fc217edf3df5e0439951413bbe05ec = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal74fc217edf3df5e0439951413bbe05ec = $attributes; } ?>
<?php $component = A17\Twill\View\Components\Fields\Select::resolve(['name' => $name,'label' => $label,'placeholder' => $placeholder,'options' => $options] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('twill::select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\A17\Twill\View\Components\Fields\Select::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal74fc217edf3df5e0439951413bbe05ec)): ?>
<?php $attributes = $__attributesOriginal74fc217edf3df5e0439951413bbe05ec; ?>
<?php unset($__attributesOriginal74fc217edf3df5e0439951413bbe05ec); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal74fc217edf3df5e0439951413bbe05ec)): ?>
<?php $component = $__componentOriginal74fc217edf3df5e0439951413bbe05ec; ?>
<?php unset($__componentOriginal74fc217edf3df5e0439951413bbe05ec); ?>
<?php endif; ?><?php /**PATH /var/www/medera-cms/storage/framework/views/bc238df7f36c8080059b0d5f94332c2c.blade.php ENDPATH**/ ?>