<?php
    use A17\Twill\Facades\TwillNavigation;
    $navigationTree = TwillNavigation::buildNavigationTree();
    // dd($navigationTree, $linkGroups);
?>
<nav class="header__nav">
    <?php $__currentLoopData = $navigationTree; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nav_branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $__currentLoopData = $nav_branch; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nav_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $nav_item->render(class: 'header__item'); ?>

            <?php if($nav_item->getChildren()): ?>
                <?php $__currentLoopData = $nav_item->getChildren(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $child_item->render(class: 'header__item header__subitem'); ?>

                    <?php if($child_item->getChildren()): ?>
                        <?php $__currentLoopData = $child_item->getChildren(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grandchild_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo $grandchild_item->render(class: 'header__item header__subsubitem'); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</nav>
<?php /**PATH /var/www/medera-cms/resources/views/vendor/twill/partials/navigation/_primary_navigation.blade.php ENDPATH**/ ?>