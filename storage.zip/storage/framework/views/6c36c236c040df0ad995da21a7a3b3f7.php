<?php
    $category_id = $category ? $category->id : null;
    $meta = null;
    if(!$category){
        $setting_block = TwillAppSettings::getGroupDataForSectionAndName('static-pages', 'library');
        $meta = arrayToObject([
            'title' => $setting_block->translatedInput('title'),
            'description' => $setting_block->translatedInput('description'),
        ]);
    }
?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="library-content">
            <h1>
                <?php echo e(__('frontend.Library')); ?>

            </h1>
            <p>
                <?php echo e(__('frontend.library-desc')); ?>

            </p>
        </div>
    </div>

    <div class="container xlarge">
        <div class="library-tabbed-list">
            <a href="<?php echo e(route('articles')); ?>" class="primary-cta __tabbed <?php echo e(!$category_id ? 'active' : ''); ?>" data-tab-id="0">
                <?php echo e(__('frontend.All')); ?>

            </a>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('blog_category', $c->slug)); ?>" class="primary-cta __tabbed <?php echo e($c->id === $category_id ? 'active' : ''); ?>" data-tab-id="<?php echo e($key); ?>">
                    <?php echo e($c->title); ?>

                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="library-search-bar">
            <form action="<?php echo e(route('articles')); ?>" method="GET" class="search-form">
                <input 
                    type="text" 
                    name="search" 
                    value="<?php echo e($searchQuery ?? ''); ?>"
                    placeholder="<?php echo e(__('Search articles...')); ?>"
                >
                <button type="submit"><?php echo e(__('Search')); ?></button>
            </form>
            <?php if(isset($searchQuery)): ?>
            <div class="search-results">
                <h2><?php echo e(__('Search results for:')); ?> "<?php echo e($searchQuery); ?>"</h2>
                <p><?php echo e($list->total()); ?> <?php echo e(__('results found')); ?></p>
            </div>
        <?php endif; ?>
        </div>
    </div>

  



    <div class="container xlarge mb-30">


        <div class="card-display library">

            <?php if($list->isNotEmpty()): ?>
                <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if (isset($component)) { $__componentOriginal2ef36d4355cd7834c6b42ce99ba2ff15 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2ef36d4355cd7834c6b42ce99ba2ff15 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.article-card','data' => ['article' => $article]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('article-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['article' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($article)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2ef36d4355cd7834c6b42ce99ba2ff15)): ?>
<?php $attributes = $__attributesOriginal2ef36d4355cd7834c6b42ce99ba2ff15; ?>
<?php unset($__attributesOriginal2ef36d4355cd7834c6b42ce99ba2ff15); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2ef36d4355cd7834c6b42ce99ba2ff15)): ?>
<?php $component = $__componentOriginal2ef36d4355cd7834c6b42ce99ba2ff15; ?>
<?php unset($__componentOriginal2ef36d4355cd7834c6b42ce99ba2ff15); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

        </div>
        <div class="pagination">

            <?php if($list->hasPages()): ?>
                <?php echo e($list->links()); ?>

            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.master', ['meta' => $meta], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/medera-cms/resources/views/site/articles.blade.php ENDPATH**/ ?>