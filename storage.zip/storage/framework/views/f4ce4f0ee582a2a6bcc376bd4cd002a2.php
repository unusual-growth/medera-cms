<input type="hidden"
    name="<?php echo e($input_name); ?>"
    value="<?php echo e($value); ?>"
    id="<?php echo e($input_id); ?>"
/>
<?php /**PATH /var/www/medera-cms/packages/unusualify/laravel-form/src/Resources/views/inputs/_hidden.blade.php ENDPATH**/ ?>