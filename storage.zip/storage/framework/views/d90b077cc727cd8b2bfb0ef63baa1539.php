<?php if (! ($disableContentFieldset)): ?>
  <?php if (! ($isCreate)): ?>
    <?php if (isset($component)) { $__componentOriginal4a91a49b910fa85bc29cab966448c662 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4a91a49b910fa85bc29cab966448c662 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'twill::partials.form.utils._fieldset','data' => ['id' => 'content','title' => ''.e($contentFieldsetLabel ?? twillTrans('twill::lang.form.content')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('twill::formFieldset'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'content','title' => ''.e($contentFieldsetLabel ?? twillTrans('twill::lang.form.content')).'']); ?>
      <?php if(isset($renderFields) && $renderFields->isNotEmpty()): ?>
        <?php $__currentLoopData = $renderFields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php echo $field->render(); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4a91a49b910fa85bc29cab966448c662)): ?>
<?php $attributes = $__attributesOriginal4a91a49b910fa85bc29cab966448c662; ?>
<?php unset($__attributesOriginal4a91a49b910fa85bc29cab966448c662); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4a91a49b910fa85bc29cab966448c662)): ?>
<?php $component = $__componentOriginal4a91a49b910fa85bc29cab966448c662; ?>
<?php unset($__componentOriginal4a91a49b910fa85bc29cab966448c662); ?>
<?php endif; ?>
  <?php else: ?>
    <?php if(isset($renderFields) && $renderFields->isNotEmpty()): ?>
      <?php $__currentLoopData = $renderFields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $field->render(); ?>

      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
  <?php endif; ?>
<?php endif; ?>

<?php if(isset($renderFieldsets) && $renderFieldsets->isNotEmpty()): ?>
  <?php $__currentLoopData = $renderFieldsets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fieldset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($isCreate): ?>
      <div class="create-fieldset-margin">
        <?php endif; ?>
        <?php if($fieldset->fields->isNotEmpty()): ?>
          <?php if (isset($component)) { $__componentOriginal4a91a49b910fa85bc29cab966448c662 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4a91a49b910fa85bc29cab966448c662 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'twill::partials.form.utils._fieldset','data' => ['id' => $fieldset->id,'title' => $fieldset->title,'open' => $fieldset->open]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('twill::formFieldset'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($fieldset->id),'title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($fieldset->title),'open' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($fieldset->open)]); ?>
            <?php $__currentLoopData = $fieldset->fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php echo $field->render(); ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4a91a49b910fa85bc29cab966448c662)): ?>
<?php $attributes = $__attributesOriginal4a91a49b910fa85bc29cab966448c662; ?>
<?php unset($__attributesOriginal4a91a49b910fa85bc29cab966448c662); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4a91a49b910fa85bc29cab966448c662)): ?>
<?php $component = $__componentOriginal4a91a49b910fa85bc29cab966448c662; ?>
<?php unset($__componentOriginal4a91a49b910fa85bc29cab966448c662); ?>
<?php endif; ?>
        <?php endif; ?>
        <?php if($isCreate): ?>
      </div>
    <?php endif; ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH /var/www/medera-cms/resources/views/vendor/twill/partials/form/renderer/base_form.blade.php ENDPATH**/ ?>