<?php
    $has_image = $block->hasImage('col_image');
    if ($has_image) {
        $image = $block->imageObject('col_image');
        $rawImageUrl = ImageService::getRawUrl($image->uuid);
    }
    $image_right = $input('image_right');
    $reverse_order_mobile = $input('reverse_order_mobile');
    $color_scheme = $input('color_scheme');
?>
<?php if(!$block->input('has_middle_image')): ?>
    <section class="flex6 <?php echo e($color_scheme == 'peach' ? 'preset-color-peach' : ''); ?>">
        <div class="container xlarge">
            <div class="row <?php echo e($reverse_order_mobile ? 'mob-rev' : ''); ?> <?php echo e($image_right ? 'reverse' : ''); ?>">
                <div class="col-xs-5 col-md-6 bg-coating">
                    <?php if($has_image): ?>
                        <img src="<?php echo e(ImageService::getRawUrl($image->uuid)); ?>" alt="<?php echo e($image->alt); ?>" />
                    <?php else: ?>
                        <div style="width: 100%; height: 100%; color: white; display: flex; justify-content: center; align-items: center; background: #427277; font-size: 32px;">
                            Please add an image.
                        </div>
                    <?php endif; ?>
                </div>
                <div class="col-xs-7 col-md-6 ">
                    <?php echo $translatedInput('text'); ?>

                </div>
            </div>
        </div>
    </section>
<?php else: ?>
    <section class="content-image-section <?php echo e($color_scheme == 'peach' ? 'preset-color-peach' : ''); ?>">
        <div class="container xlarge">
            <div class="row justify-space-between">
                <div class="col-sm-5">
                    <div>
                        <?php echo $translatedInput('text'); ?>

                    </div>
                </div>
                <div class="col-sm-6">
                    <?php if($has_image): ?>
                        <img src="<?php echo e(ImageService::getRawUrl($image->uuid)); ?>" alt="" />
                    <?php else: ?>
                        <div style="width: 100%; height: 100%; color: white; display: flex; justify-content: center; align-items: center; background: #427277; font-size: 32px;">
                            Please add an image.
                        </div>
                    <?php endif; ?>
                    <img class="bottle-img" src="<?php echo e($block->image('middle_image')); ?>" alt="" />
                </div>

            </div>
        </div>
    </section>
<?php endif; ?>
<?php /**PATH /var/www/medera-cms/resources/views/components/twill/blocks/doublecolumncontent.blade.php ENDPATH**/ ?>