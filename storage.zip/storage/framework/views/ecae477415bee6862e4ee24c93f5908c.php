<?php
    $id = uniqid('slider-');
    $fid = uniqid();
    $form_id = uniqid('form-');
    $picture_hierarchy = [
        [
            'key' => 'mobile_image',
            'src' => null,
            'media' => null,
        ],
        [
            'key' => 'tablet_image',
            'src' => null,
            'media' => '(min-width: 768px)',
        ],
        [
            'key' => 'desktop_image',
            'src' => null,
            'media' => '(min-width: 1024px)',
        ],
    ];
    if (!function_exists('setUpPictureForSlide')) {
        function setUpPictureForSlide($slide, $arr, $setMediaNull = false, $i = 0)
        {
            if ($i > array_key_last($arr)) {
                return $arr;
            }
            if ($setMediaNull) {
                $arr[$i]['media'] = null;
            }

            if (!$slide->hasImage($arr[$i]['key'])) {
                unset($arr[$i]);
                return setUpPictureForSlide($slide, $arr, true, $i + 1);
            }
            $arr[$i]['src'] = ImageService::getRawUrl($slide->imageObject($arr[$i]['key'])->uuid);
            // dd($slide->imageObject($arr[$i]['key']));
            return setUpPictureForSlide($slide, $arr, false, $i + 1);
        }
    }
    $all_slide_images = collect([]);
    foreach($repeater('slides') as $key => $slide){
        $all_slide_images[$key] = setUpPictureForSlide($slide->renderData->block, $picture_hierarchy);
    }
    // dd($all_slide_images);
?>
<?php $__env->startPush('preload'); ?>
    <?php
        $slide = $all_slide_images->first();
            ?>
    <?php $__currentLoopData = $slide; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <link rel="preload" href="<?php echo e($media['src']); ?>" as="image" media="<?php echo e($media['media']); ?>">
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopPush(); ?>

<section class="<?php echo \Illuminate\Support\Arr::toCssClasses(['hero-slider-sect', 'formed']); ?>">
    <div class="slide-backgrounds">
        <?php $__currentLoopData = $all_slide_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <picture class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                'active' => $loop->first
            ]); ?>" data-id="<?php echo e($loop->index); ?>" >
                <?php for($i = array_key_last($slide); $i >= 0; $i--): ?>
                    <?php
                        $item = $slide[$i] ?? null;
                        if (!$item) {
                            break;
                        }
                    ?>
                    <?php if($item['media']): ?>
                        <source srcset="<?php echo e($item['src']); ?>" media="<?php echo e($item['media']); ?>">
                    <?php else: ?>
                        <img src="<?php echo e($item['src']); ?>">
                    <?php endif; ?>
                <?php endfor; ?>
            </picture>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>



    <div class="container xlarge">
        <div class="row">
            <div class="slider-col col-md-7 col-sm-6">
                <div id="<?php echo e($id); ?>" class='swiper hero-slider'>
                    <div class="swiper-wrapper">
                        <?php $__currentLoopData = $repeater('slides'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $repeaterItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $_renderData = $repeaterItem->renderData;
                                $slide_block = $_renderData->block;
                                $top_title = $slide_block->translatedInput('top_title');
                                $heading = $slide_block->translatedInput('heading');
                                $text = $slide_block->translatedInput('text');
                                $link = $slide_block->translatedInput('link');
                                $link_text = $slide_block->translatedInput('link_text');
                            ?>
                            <div class="swiper-slide">
                                <span class="top-title">
                                    <?php echo $top_title; ?>

                                </span>
                                <?php echo $heading; ?>

                                <?php echo $text; ?>

                                <a href="<?php echo e($link); ?>"><?php echo e($link_text); ?></a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>


            <div class="form-col md-5 col-sm-6">
                <?php
                    $conf = config('forms.request-form');
                    $conf["id"] = $form_id
                ?>
                <?php echo $__env->make('unusual_form::layouts._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->with(['formData' => $conf])->render(); ?>
                
            </div>
        </div>
        <div class="hero-pagination swiper-pagination  swiper-pagination-custom"></div>
    </div>
    <div class="autoplay-progress">
        <svg viewBox="0 0 48 48">
            <circle cx="24" cy="24" r="20"></circle>
        </svg>
        <span></span>
    </div>
</section>


<?php $__env->startPush('custom-last-script'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            let selector =  "#<?php echo e($id); ?>";
            window.swipers["<?php echo e($fid); ?>"] = new _swiper(selector, {
                    modules: [
                        _swiperController,
                        _swiperPagination,
                        _swiperNavigation,
                        _swiperAutoplay,
                        _swiperCreativeEffect,
                        _swiperKeyboard,
                        _swiperEffectFade,
                        _swiperFreeMode,
                    ],
                    slidesPerView: 1,
                    spaceBetween: 0,
                    loop: 1,
                    speed: 800,
                    autoplay: {
                        delay: 10000,
                        disableOnInteraction: false,
                    },
                    on: {
                        autoplayTimeLeft: (swiper, time, progress) => {
                            var progressCircle = $(".autoplay-progress svg")[0];
                            var progressContent = $(".autoplay-progress span")[0];
                            progressCircle.style.setProperty("--progress", 1 - progress);
                            progressContent.textContent = `${Math.ceil(time / 1000)}s`;
                        },
                        slideChangeTransitionStart: (swiper) => {
                            $('.slide-backgrounds picture.active').removeClass('active');
                            $('.slide-backgrounds picture[data-id="' + swiper.realIndex + '"]').addClass('active');
                        },
                    },
                    effect: 'creative',
                    creativeEffect: {
                        prev: {
                            translate: [0, 0, -500],
                            opacity: 0,
                        },
                        next: {
                            translate: ['-100%', 0, 0],
                            opacity: 1,
                        },
                    },
                    pagination: {
                        el: ' .hero-pagination.swiper-pagination',
                        bulletClass: "swiper-pagination-bullet",
                        bulletActiveClass: "active-tab",
                        type: "custom",
                        clickable: 1,
                        renderCustom: renderBulletsWithFraction,
                    },
                }
            );
            window.swipers["<?php echo e($fid); ?>"].autoplay.stop();
        });
        window.addEventListener('load', function () {
            window.swipers["<?php echo e($fid); ?>"].autoplay.start();
        })
    </script>
<?php $__env->stopPush(); ?>
<?php if($inEditor): ?>
<script>
    function initializeSwiper<?php echo e($fid); ?>(selector) {
        new _swiper(selector, {
                modules: [
                    _swiperController,
                    _swiperPagination,
                    _swiperNavigation,
                    _swiperAutoplay,
                    _swiperCreativeEffect,
                    _swiperKeyboard,
                    _swiperEffectFade,
                    _swiperFreeMode,
                ],
                slidesPerView: 1,
                spaceBetween: 0,
                loop: 1,
                speed: 800,
                autoplay: {
                    delay: 10000,
                    disableOnInteraction: false,
                },
                on: {
                    autoplayTimeLeft: (swiper, time, progress) => {
                        var progressCircle = $(".autoplay-progress svg")[0];
                        var progressContent = $(".autoplay-progress span")[0];
                        progressCircle.style.setProperty("--progress", 1 - progress);
                        progressContent.textContent = `${Math.ceil(time / 1000)}s`;
                    },
                    slideChangeTransitionStart: (swiper) => {
                            $('.slide-backgrounds picture.active').removeClass('active');
                            $('.slide-backgrounds picture[data-id="' + swiper.realIndex + '"]').addClass('active');
                        },
                },
                effect: 'creative',
                creativeEffect: {
                    prev: {
                        translate: [0, 0, -500],
                        opacity: 0,
                    },
                    next: {
                        translate: ['-100%', 0, 0],
                        opacity: 1,
                    },
                },
                pagination: {
                    el: selector+'+.hero-pagination.swiper-pagination',
                    bulletClass: "swiper-pagination-bullet",
                    bulletActiveClass: "active-tab",
                    type: "custom",
                    clickable: 1,
                    renderCustom: renderBulletsWithFraction,
                },
            }

        );
    }
    document.addEventListener('DOMContentLoaded', function() {
        initializeSwiper<?php echo e($fid); ?>('#<?php echo e($id); ?>');
    });
</script>
<?php endif; ?>
<?php /**PATH /var/www/medera-cms/resources/views/components/twill/blocks/heroslider.blade.php ENDPATH**/ ?>