<?php if($unpack ?? false): ?>
    <a17-singleselect
        label="<?php echo e($label); ?>"
        <?php echo $formFieldName(); ?>

        :options='<?php echo e(json_encode($options)); ?>'
        :columns="<?php echo e($columns); ?>"
        <?php if(isset($default)): ?> selected="<?php echo e($default); ?>" <?php endif; ?>
        <?php if($required): ?> :required="true" <?php endif; ?>
        <?php if($inModal): ?> :in-modal="true" <?php endif; ?>
        <?php if($inTable): ?> :in-table="true" :inline="true" <?php endif; ?>
        <?php if(!$inGrid): ?> :grid="false" <?php endif; ?>
        <?php if($disabled): ?> disabled <?php endif; ?>
        <?php if($addNew): ?> add-new='<?php echo e($storeUrl); ?>' <?php elseif($note): ?> note='<?php echo e($note); ?>' <?php endif; ?>
        :has-default-store="true"
        in-store="value"
    >
        <?php if($addNew): ?>
            <div slot="addModal">
                <?php
                    unset($note, $placeholder, $emptyText, $default, $required, $inModal, $addNew, $options);
                ?>
                <?php
            if( view()->exists(twillViewName(($formModuleName ?? null), 'create'))) {
                echo $__env->make(twillViewName(($formModuleName ?? null), 'create'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->with( ['renderForModal' => true, 'fieldsInModal' => true])->render();
            } elseif( view()->exists('twill.partials.create')) {
                echo $__env->make('twill.partials.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->with( ['renderForModal' => true, 'fieldsInModal' => true])->render();
            } elseif( view()->exists('twill::'.($formModuleName ?? null).'.create')) {
                echo $__env->make('twill::'.($formModuleName ?? null).'.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->with( ['renderForModal' => true, 'fieldsInModal' => true])->render();
            } elseif( view()->exists('twill::partials.create')) {
                echo $__env->make('twill::partials.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->with( ['renderForModal' => true, 'fieldsInModal' => true])->render();
            }
            ?>
            </div>
        <?php endif; ?>
    </a17-singleselect>
<?php elseif($native ?? false): ?>
    <a17-select
        label="<?php echo e($label); ?>"
        <?php echo $formFieldName(); ?>

        :options='<?php echo e(json_encode($options)); ?>'
        <?php if($placeholder): ?> placeholder="<?php echo e($placeholder); ?>" <?php endif; ?>
        <?php if(isset($default)): ?> selected="<?php echo e($default); ?>" <?php endif; ?>
        <?php if($required): ?> :required="true" <?php endif; ?>
        <?php if($inModal): ?> :in-modal="true" <?php endif; ?>
        <?php if($disabled): ?> disabled <?php endif; ?>
        <?php if($addNew): ?> add-new='<?php echo e($storeUrl); ?>' <?php elseif($note): ?> note='<?php echo e($note); ?>' <?php endif; ?>
        :has-default-store="true"
        size="large"
        in-store="value"
    >
        <?php if($addNew): ?>
            <div slot="addModal">
                <?php
                    unset($note, $placeholder, $emptyText, $default, $required, $inModal, $addNew, $options);
                ?>
                <?php
            if( view()->exists(twillViewName(($formModuleName ?? null), 'create'))) {
                echo $__env->make(twillViewName(($formModuleName ?? null), 'create'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->with( ['renderForModal' => true, 'fieldsInModal' => true])->render();
            } elseif( view()->exists('twill.partials.create')) {
                echo $__env->make('twill.partials.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->with( ['renderForModal' => true, 'fieldsInModal' => true])->render();
            } elseif( view()->exists('twill::'.($formModuleName ?? null).'.create')) {
                echo $__env->make('twill::'.($formModuleName ?? null).'.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->with( ['renderForModal' => true, 'fieldsInModal' => true])->render();
            } elseif( view()->exists('twill::partials.create')) {
                echo $__env->make('twill::partials.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->with( ['renderForModal' => true, 'fieldsInModal' => true])->render();
            }
            ?>
            </div>
        <?php endif; ?>
    </a17-select>
<?php else: ?>
    <a17-vselect
        label="<?php echo e($label); ?>"
        <?php echo $formFieldName(); ?>

        :options='<?php echo e(json_encode($options)); ?>'
        <?php if($emptyText ?? false): ?> empty-text="<?php echo e($emptyText); ?>" <?php endif; ?>
        <?php if($placeholder): ?> placeholder="<?php echo e($placeholder); ?>" <?php endif; ?>
        <?php if(isset($default)): ?> :selected="<?php echo e(json_encode(collect($options)->first(function ($option) use ($default) {
            return $option['value'] === $default;
        }))); ?>" <?php endif; ?>
        <?php if($required): ?> :required="true" <?php endif; ?>
        <?php if($disabled): ?> disabled <?php endif; ?>
        <?php if($inModal): ?> :in-modal="true" <?php endif; ?>
        <?php if($addNew): ?> add-new='<?php echo e($storeUrl); ?>' <?php elseif($note): ?> note='<?php echo e($note); ?>' <?php endif; ?>
        :has-default-store="true"
        <?php if($searchable): ?> :searchable="true" <?php endif; ?>
        <?php if($clearable): ?> :clearable="true" <?php endif; ?>
        size="large"
        in-store="inputValue"
    >
        <?php if($addNew): ?>
            <div slot="addModal">
                <?php
                    unset($note, $placeholder, $emptyText, $default, $required, $inModal, $addNew, $options);
                ?>
                <?php
            if( view()->exists(twillViewName(($formModuleName ?? null), 'create'))) {
                echo $__env->make(twillViewName(($formModuleName ?? null), 'create'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->with( ['renderForModal' => true, 'fieldsInModal' => true])->render();
            } elseif( view()->exists('twill.partials.create')) {
                echo $__env->make('twill.partials.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->with( ['renderForModal' => true, 'fieldsInModal' => true])->render();
            } elseif( view()->exists('twill::'.($formModuleName ?? null).'.create')) {
                echo $__env->make('twill::'.($formModuleName ?? null).'.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->with( ['renderForModal' => true, 'fieldsInModal' => true])->render();
            } elseif( view()->exists('twill::partials.create')) {
                echo $__env->make('twill::partials.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->with( ['renderForModal' => true, 'fieldsInModal' => true])->render();
            }
            ?>
            </div>
        <?php endif; ?>
    </a17-vselect>
<?php endif; ?>

<?php if (! ($renderForBlocks || $renderForModal || (!isset($item->$name) && is_null($formFieldsValue = getFormFieldsValue($form_fields, $name))))): ?>
<?php $__env->startPush('vuexStore'); ?>
    <?php echo $__env->make('twill::partials.form.utils._selector_input_store', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>
<?php endif; ?>
<?php /**PATH /var/www/medera-cms/resources/views/vendor/twill/partials/form/_select.blade.php ENDPATH**/ ?>