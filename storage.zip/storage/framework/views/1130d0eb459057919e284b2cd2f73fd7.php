<?php
    $input_id =  "inputID_" . mt_rand(100000,999999);
    if(isset($model))
        $value = $model->getFormInputValue( $input_name);
?>


<?php $__env->startSection('input'); ?>



<?php if(isset($floating) && $floating == true): ?>



<?php else: ?>
    <?php if(isset($label)): ?>
    <label><?php echo __($label); ?></label>
    <?php endif; ?>
    <input
        class="form-control <?php echo e($class ?? ''); ?>"
        type="tel"
        id="<?php echo e($input_id); ?>"
        placeholder="<?php echo e(__($placeholder) ?? ''); ?>"
        name="<?php echo e($input_name); ?>"
        value="<?php echo e(isset($model) ? $model->getFormInputValue($input_name) : ''); ?>"
        <?php echo e($props); ?>

        />
    <span class="help-block" for="<?php echo e($input_name); ?>">
        <?php echo e($help_label ?? ''); ?>

    </span>
    
    
<?php endif; ?>

<?php $__env->stopSection(true); ?>




<?php echo $__env->make('unusual_form::layouts._input-template', ['arr' => $arr], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/medera-cms/packages/unusualify/laravel-form/src/Resources/views/inputs/_phone.blade.php ENDPATH**/ ?>