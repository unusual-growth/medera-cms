<?php
    $id = uniqid('slider-');
    $fid = uniqid();
?>
<section class="accordion-slider-section" data-swiper-id="<?php echo e($fid); ?>">
    <div class="container xlarge">
        <div class="row gap-30">
            <div class="col-md-7">
                <div id="<?php echo e($id); ?>" class="swiper accordion-image-slider height-100 border-radius-oval">

                    <div class="swiper-wrapper">
                        <?php $__currentLoopData = $repeater('items'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $_block = $item->renderData->block;
                                $_img = $_block->imagesAsArrays('image')[0];
                            ?>
                            <div class="swiper-slide">
                                <picture>
                                    <img src="<?php echo e($_img['src']); ?>" alt="<?php echo e($_img['alt']); ?>" />
                                </picture>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                    

                    
            </div>
            <div class="col-md-5 ">
                <?php $__currentLoopData = $repeater('items'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $_block = $item->renderData->block;
                        $_img = $_block->imagesAsArrays('icon')[0];
                    ?>
                    
                    <div class="accordion-item <?php echo e($loop->first ? 'active' : ''); ?>" data-index="<?php echo e($key); ?>">
                        <div class="title" data-accordion="<?php echo e($key); ?>">
                                <div style="width: 34px; height: 34px; --mask-image: url('<?php echo e($_img['src']); ?>')">
                                </div>
                                <h4 itemprop="name"><?php echo e($_block->translatedInput('title')); ?></h4>
                        </div>
                        <div class="content-container">
                            <div class="content" itemprop="text">
                                <?php echo $_block->translatedInput('content'); ?>

                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</section>


<?php $__env->startPush('custom-last-script'); ?>
    <script>
        function initializeSwiper<?php echo e($fid); ?>(selector) {
            return new _swiper(selector, {
                    modules: [
                    ],
                    slidesPerView: 1,
                    spaceBetween: 0,
                    loop: false,
                    rewind: false,
                    speed: 600,
                    allowTouchMove: false,
                }

            );
        }
        document.addEventListener('DOMContentLoaded', function() {
            window.swipers["<?php echo e($fid); ?>"] = initializeSwiper<?php echo e($fid); ?>('#<?php echo e($id); ?>');
        });
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH /var/www/medera-cms/resources/views/components/twill/blocks/accordionwithdynamicimages.blade.php ENDPATH**/ ?>