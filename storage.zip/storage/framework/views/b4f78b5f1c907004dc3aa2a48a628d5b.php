<?php
    $titleFormKey = $titleFormKey ?? 'title';
    $titleFormLabel = $titleFormLabel ?? 'Title';
?>
<?php if (isset($component)) { $__componentOriginal6dbb8a3d0dca16b32bd023fdc4ac8605 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6dbb8a3d0dca16b32bd023fdc4ac8605 = $attributes; } ?>
<?php $component = A17\Twill\View\Components\Fields\Input::resolve(['name' => $titleFormKey,'label' => $titleFormKey === 'title' && $titleFormLabel === 'Title' ? twillTrans('twill::lang.modal.title-field') : $titleFormLabel,'translated' => $translateTitle ?? false,'required' => true,'onChange' => 'formatPermalink'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('twill::input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\A17\Twill\View\Components\Fields\Input::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6dbb8a3d0dca16b32bd023fdc4ac8605)): ?>
<?php $attributes = $__attributesOriginal6dbb8a3d0dca16b32bd023fdc4ac8605; ?>
<?php unset($__attributesOriginal6dbb8a3d0dca16b32bd023fdc4ac8605); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6dbb8a3d0dca16b32bd023fdc4ac8605)): ?>
<?php $component = $__componentOriginal6dbb8a3d0dca16b32bd023fdc4ac8605; ?>
<?php unset($__componentOriginal6dbb8a3d0dca16b32bd023fdc4ac8605); ?>
<?php endif; ?>

<?php if($permalink ?? true): ?>
    <?php if (isset($component)) { $__componentOriginal6dbb8a3d0dca16b32bd023fdc4ac8605 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6dbb8a3d0dca16b32bd023fdc4ac8605 = $attributes; } ?>
<?php $component = A17\Twill\View\Components\Fields\Input::resolve(['name' => 'slug','label' => twillTrans('twill::lang.modal.permalink-field'),'translated' => true,'ref' => 'permalink','prefix' => $permalinkPrefix ?? ''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('twill::input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\A17\Twill\View\Components\Fields\Input::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6dbb8a3d0dca16b32bd023fdc4ac8605)): ?>
<?php $attributes = $__attributesOriginal6dbb8a3d0dca16b32bd023fdc4ac8605; ?>
<?php unset($__attributesOriginal6dbb8a3d0dca16b32bd023fdc4ac8605); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6dbb8a3d0dca16b32bd023fdc4ac8605)): ?>
<?php $component = $__componentOriginal6dbb8a3d0dca16b32bd023fdc4ac8605; ?>
<?php unset($__componentOriginal6dbb8a3d0dca16b32bd023fdc4ac8605); ?>
<?php endif; ?>
<?php endif; ?>
<?php /**PATH /var/www/medera-cms/resources/views/vendor/twill/partials/create.blade.php ENDPATH**/ ?>