<div class="svg-sprite">
    <?php echo $__env->make('twill::partials.icons.icons-svg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('twill::partials.icons.icons-files-svg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('twill::partials.icons.icons-wysiwyg-svg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php /**PATH /var/www/medera-cms/resources/views/vendor/twill/partials/icons/svg-sprite.blade.php ENDPATH**/ ?>