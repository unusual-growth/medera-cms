    
    <?php
        $packagingTypes = [
            [
                'icon' => '/dummy-img/mini-img.png',
                'title' => 'Standardized Dosage',
                'description' =>
                    'Each capsule contains the same amount of active ingredients to increase product effectiveness.',
            ],
            [
                'icon' => '/dummy-img/mini-img.png',
                'title' => 'Hygiene',
                'description' => 'It ensures maximum hygiene reliability by securely preserving the product. ',
            ],
            [
                'icon' => '/dummy-img/mini-img.png',
                'title' => 'Consumer Reach',
                'description' => 'The capsule formulation expands the product’s appeal to a broader consumer base.',
            ],
            [
                'icon' => '/dummy-img/mini-img.png',
                'title' => 'High Performance',
                'description' =>
                    'Resistant to stomach acid, the capsules dissolve in the intestines for enhanced performance.',
            ],
        ];
    ?>
    <section class="list-card">
        <div class="container xlarge">
            <div class="row">
                <div class="fab-card">
                    <?php $__currentLoopData = $repeater("features_1"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $_block = $item->renderData->block;
                            $_img = $_block->imagesAsArrays('image')[0];
                        ?>
                        <div>
                            <img
                                width="282"
                                height="172"
                                src="<?php echo e($_img['src']); ?>"
                                alt="<?php echo e($_img['alt']); ?>"
                            />
                            <h3><?php echo e($_block->translatedInput('title')); ?></h3>
                            <p><?php echo e($_block->translatedInput('description')); ?></p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </section>
<?php /**PATH /var/www/medera-cms/resources/views/components/twill/blocks/featuredescriptionwithimage.blade.php ENDPATH**/ ?>