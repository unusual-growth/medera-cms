<section class="double-crossed-colums-with-content">
  <div class="container xlarge">
      <div class="row gap-30">
          <div class="col-md-6 left-bubble d-flex align-items-center justify-content-center">
              <?php echo $translatedInput('text_left'); ?>

          </div>
          <div class="col-md-7 right-bubble d-flex align-items-center justify-content-center">
            <?php echo $translatedInput('text_right'); ?>

          </div>
      </div>
  </div>
</section>
<?php /**PATH /var/www/medera-cms/resources/views/components/twill/blocks/doublecrossedcolumnswithcontent.blade.php ENDPATH**/ ?>