<!DOCTYPE html>
<html lang="<?php echo e(LaravelLocalization::getCurrentLocale()); ?>">
<?php echo $__env->make('site.meta.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
    <?php echo TwillAppSettings::get('custom-scripts.gtm.bodyscript'); ?>

    <style>
        :root {
            --color-primary: #901540;
        }
    </style>

    

    <?php echo $__env->make('site.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>
     <?php echo $__env->make('site.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php if(!(isset($noFooter) && $noFooter)): ?>
        
    <?php endif; ?>
    <div class="floating-form">
        <div class="row no-wrap justify-content-space-between align-items-center activator">
            <h3 class="heading color-white"><?php echo e(__('util.request-form-title')); ?></h3>
            <svg class="arrow" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M5 15L12 8L19 15" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
        </div>
        <div class="formcontainer active">
            <div>
                <?php
                    $form = config('forms.request-form');
                    $form["id"] = uniqid();
                ?>
                <?php echo $__env->make('unusual_form::layouts._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->with(['formData' => $form])->render(); ?>
                
            </div>
        </div>
    </div>
</body>

    <?php echo $__env->yieldPushContent('custom-last-script'); ?>
    <?php echo $__env->yieldPushContent('final-scripts'); ?>
</html>
<?php /**PATH /var/www/medera-cms/resources/views/site/master.blade.php ENDPATH**/ ?>