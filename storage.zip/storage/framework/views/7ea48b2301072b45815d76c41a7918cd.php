<?php
    $has_desktop_image = $block->hasImage('desktop_image');
    $has_tablet_image = $block->hasImage('tablet_image');
    $has_mobile_image = $block->hasImage('mobile_image');
?>
<section class="banner glass"
    style="
        <?php if($has_desktop_image): ?>
            <?php echo e('--desktop-image: url(' . $block->image('desktop_image') . ');'); ?>

        <?php endif; ?>
        <?php if($has_tablet_image): ?>
            <?php echo e('--tablet-image: url(' . $block->image('tablet_image') . ');'); ?>

        <?php endif; ?>
        <?php if($has_mobile_image): ?>
            <?php echo e('--mobile-image: url(' . $block->image('mobile_image') . ');'); ?>

        <?php endif; ?>
    "
    >
    <div class="container xlarge">
        <div class="flex-column justify-content-center align-items-center">
            <div class="window">
                <?php echo $block->translatedInput('content'); ?>

                <a href="<?php echo e($block->translatedInput('link_url')); ?>" class="primary-cta"><?php echo e($block->translatedInput('link_text')); ?></a>
            </div>
        </div>
    </div>
</section>
<?php /**PATH /var/www/medera-cms/resources/views/components/twill/blocks/inlinebannerwithglasscontainer.blade.php ENDPATH**/ ?>