
    
    <section class="circle-card">
        <?php if($input('has_section_content') && $translatedInput('section_content')): ?>
            <div class="container xlarge">
                <div class="section-desctiption heading">
                    <?php echo $translatedInput('section_content'); ?>

                </div>
            </div>
        <?php endif; ?>
        <div class="container xlarge">
            <div class="cards">
                <?php $__currentLoopData = $repeater('features'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $_block = $item->renderData->block;
                        $_img = $_block->imagesAsArrays('image')[0];

                    ?>
                        <div class="card <?php echo e(PRESETS[$_block->input('color_preset')]['class']); ?>">
                            <img width="232" height="232" src="<?php echo e($_img['src']); ?>" alt="<?php echo e($_img['alt']); ?>" />
                            <p><?php echo e($_block->translatedInput('title')); ?></p>
                        </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
<?php /**PATH /var/www/medera-cms/resources/views/components/twill/blocks/featureheadlineswithsphericalimages.blade.php ENDPATH**/ ?>